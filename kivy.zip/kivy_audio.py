import os
import sys
import time
import random
from threading import Thread
import traceback
from kivy.core.audio import SoundLoader  # Kivy原生音频（手机兼容）
from plyer import tts  # 跨平台文本朗读（手机适配）

# 核心修改：直接写死项目根路径（替换成你实际的路径！）
BASE_DIR = "D:/AncientLiteraryApp"  # 改成你存放resources的根目录
print(f"✅ 强制使用绝对路径：{BASE_DIR}")

# 音频路径配置（现在会正确指向你的音乐文件）
AUDIO_PATHS = {
    "cover": os.path.join(BASE_DIR, "resources", "audio", "bgm", "cover_bg.mp3"),
    "login": os.path.join(BASE_DIR, "resources", "audio", "bgm", "login_bg.mp3"),
    "main": os.path.join(BASE_DIR, "resources", "audio", "bgm", "main_bg"),  # 主界面音乐目录
    "func": os.path.join(BASE_DIR, "resources", "audio", "bgm", "func_bg.mp3")
}

# 音量配置（分场景独立控制）
VOLUME_CONFIG = {
    "cover": 0.5,
    "login": 0.4,
    "main": 0.5,
    "func": 0.25
}

# --------------------------
# 文本朗读核心逻辑（手机端适配版）
# --------------------------
is_reading = False  # 全局朗读状态
current_text = ""  # 当前朗读文本
read_thread = None  # 朗读线程


def read_toggle(text):
    """核心切换方法：开始/暂停/恢复（手机兼容）"""
    global is_reading, current_text, read_thread
    if not is_reading or current_text == "":
        current_text = text.strip()
        if not current_text:
            print("📝 无朗读文本，跳过操作")
            return

    # 正在朗读 → 暂停
    if is_reading:
        try:
            tts.stop()  # 手机端停止朗读
        except Exception as e:
            print(f"⚠️  暂停朗读警告：{e}")
        is_reading = False
        print("⏸️  朗读已暂停，再点朗读键恢复")
        return

    # 未朗读/已暂停 → 开始/恢复
    try:
        if read_thread and read_thread.is_alive():
            tts.stop()
        read_thread = Thread(target=_read_worker, args=(current_text,), daemon=True)
        read_thread.start()
        is_reading = True
        print("▶️  开始/恢复朗读")
    except Exception as e:
        print(f"❌ 启动朗读失败：{e}")
        traceback.print_exc()
        is_reading = False


def _read_worker(text):
    """朗读工作线程（手机端适配，异常容错）"""
    global is_reading, current_text
    try:
        tts.speak(text)  # plyer tts 跨平台朗读
        is_reading = False
        current_text = ""
        print("🔚 朗读自然结束，状态已重置")
    except Exception as e:
        if "stop" not in str(e).lower():
            print(f"❌ 朗读线程异常：{e}")
            traceback.print_exc()
    finally:
        is_reading = False


def stop_read():
    """停止朗读（手机端彻底重置，容错增强）"""
    global is_reading, current_text, read_thread
    try:
        tts.stop()  # 停止手机端朗读
        if read_thread and read_thread.is_alive():
            read_thread = None
        is_reading = False
        current_text = ""
        print("⏹️  朗读已彻底停止，所有状态已重置")
    except Exception as e:
        print(f"❌ 停止朗读失败：{e}")
        traceback.print_exc()


# --------------------------
# 背景音乐播放（Kivy原生手机兼容版，全场景适配）
# --------------------------
class KivyAudioPlayer:
    def __init__(self):
        self.current_scene = None  # 当前播放场景
        self.main_music_list = []  # 主界面音乐列表
        self.play_thread = None  # 播放线程
        self.is_running = True  # 播放循环标记
        self.current_sound = None  # 当前播放的音频对象
        self.is_playing = False  # 新增：播放状态锁，防叠加
        self._load_main_music_list()  # 初始化加载主界面音乐

    def _load_main_music_list(self):
        """加载主界面音乐列表（兼容所有main开头的mp3，适配主界面逻辑）"""
        self.main_music_list.clear()
        main_dir = os.path.dirname(AUDIO_PATHS["main"])
        if not os.path.exists(main_dir):
            os.makedirs(main_dir, exist_ok=True)
            print(f"📁 创建主界面音乐目录：{main_dir}")
            return

        # 核心适配：筛选所有main开头的mp3（兼容main1.mp3、main_bg.mp3等）
        for file in os.listdir(main_dir):
            if file.lower().startswith("main") and file.lower().endswith(".mp3"):
                self.main_music_list.append(os.path.join(main_dir, file))

        # 去重+打乱顺序
        self.main_music_list = list(set(self.main_music_list))
        random.shuffle(self.main_music_list)

        if self.main_music_list:
            print(
                f"✅ 加载主界面音乐 {len(self.main_music_list)} 首：{[os.path.basename(f) for f in self.main_music_list]}")
        else:
            print(f"⚠️  主界面音乐文件缺失：请在 {main_dir} 放入 main开头的mp3文件（如main1.mp3、main_bg.mp3）")

    def _play_main_music_loop(self):
        """主界面音乐循环播放（随机切歌+播放完停3秒，完全适配主界面逻辑）"""
        self.is_playing = True  # 标记播放中
        while self.is_running and self.current_scene == "main" and self.main_music_list:
            current_music = random.choice(self.main_music_list)
            try:
                self.current_sound = SoundLoader.load(current_music)
                if self.current_sound:
                    self.current_sound.volume = VOLUME_CONFIG["main"]
                    self.current_sound.play()
                    print(
                        f"🎵 主界面播放：{os.path.basename(current_music)}（时长：{round(self.current_sound.length, 1)}秒）")
                    # 核心修复：加self.current_sound非空判断，避免播放中对象为空报错
                    while self.current_sound and self.current_sound.state == 'play' and self.is_running and self.current_scene == "main":
                        time.sleep(0.5)
                    # 播放完停3秒再切歌（适配原逻辑）
                    if self.is_running and self.current_scene == "main":
                        time.sleep(3)
                else:
                    print(f"❌ 无法加载音频：{current_music}")
                    # 修复：移除前先判断元素是否存在，避免KeyError
                    if current_music in self.main_music_list:
                        self.main_music_list.remove(current_music)
            except Exception as e:
                print(f"❌ 主界面播放失败：{e}")
                traceback.print_exc()  # 新增：打印详细错误，方便排查
                continue
        self.is_playing = False  # 播放结束重置

    def _play_single_loop_music(self, scene):
        """通用单文件循环播放（封面/登录/功能页）【核心修改：func加载失败直接终止，不触发其他逻辑】"""
        music_file = AUDIO_PATHS.get(scene)
        if not music_file or not os.path.exists(music_file):
            print(f"⚠️  {scene}场景音乐缺失/不存在：{music_file}")
            self.is_playing = False  # 重置播放状态
            self.current_scene = None  # 清空场景，防止串音
            return

        while self.is_running and self.current_scene == scene:
            try:
                self.current_sound = SoundLoader.load(music_file)
                if self.current_sound:
                    self.current_sound.volume = VOLUME_CONFIG[scene]
                    self.current_sound.loop = True  # 无限循环
                    self.current_sound.play()
                    print(f"🎵 {scene}场景播放：{os.path.basename(music_file)}（无限循环）")
                    # 核心修复：加self.current_sound非空判断
                    while self.current_sound and self.current_sound.state == 'play' and self.is_running and self.current_scene == scene:
                        time.sleep(0.5)
                else:
                    print(f"❌ 无法加载{scene}音频文件：{music_file}")
                    self.is_playing = False
                    self.current_scene = None
                    break  # 直接终止，不循环重试
            except Exception as e:
                print(f"❌ {scene}场景播放异常：{e}")
                traceback.print_exc()  # 新增：打印详细错误
                self.is_playing = False
                self.current_scene = None
                break  # 直接终止，不循环重试

    def play_scene_music(self, scene):
        """播放场景音乐（全场景适配：cover/login/main/func + 防重复）"""
        # 新增：强制锁死场景，防止主界面音频复活覆盖
        if scene in ["cover", "login", "func"]:
            self.current_scene = scene  # 先锁定场景，再停止旧音频
            self.is_running = False  # 先终止所有旧循环

        # 原逻辑：同场景已在播放，直接返回
        if self.current_scene == scene and self.is_playing:
            return
        # 先停止当前所有音乐
        self.stop_bg_music()

        # 设置当前场景并启动播放
        self.current_scene = scene
        self.is_running = True

        if scene == "main":
            # 主界面：随机切歌+停3秒逻辑
            if self.main_music_list:
                self.play_thread = Thread(target=self._play_main_music_loop, daemon=True)
                self.play_thread.start()
            else:
                print(f"⚠️  主界面无可用音乐，跳过播放")
                self.is_playing = False
                self.current_scene = None
        elif scene in ["cover", "login", "func"]:
            # 其他场景：单文件无限循环（修复：加self.调用方法）
            self.play_thread = Thread(target=self._play_single_loop_music, args=(scene,), daemon=True)
            self.play_thread.start()
        else:
            print(f"⚠️  未知场景：{scene}，不播放音乐")
            self.is_playing = False
            self.current_scene = None

    def switch_main_music(self):
        """手动切换主界面下一首音乐（适配主界面点击刷新）"""
        if self.current_scene == "main" and self.main_music_list:
            self.stop_bg_music()  # 先停当前
            self.current_scene = "main"
            self.is_running = True
            self.play_thread = Thread(target=self._play_main_music_loop, daemon=True)
            self.play_thread.start()
            print("🔄 主界面音乐已手动切换")

    def stop_bg_music(self):
        """停止背景音乐（释放手机音频资源，容错增强）"""
        self.is_running = False  # 强制终止音频循环
        self.is_playing = False  # 重置播放锁
        self.current_scene = None  # 新增：强制清空场景标记，防止串音

        # 停止当前播放的音频
        if self.current_sound:
            try:
                self.current_sound.stop()
            except:
                pass
            self.current_sound = None

        # 等待线程结束（避免资源泄漏）
        if self.play_thread and self.play_thread.is_alive():
            try:
                self.play_thread.join(timeout=1)
            except:
                pass
        self.play_thread = None  # 新增：清空线程对象

        print("⏹️  背景音乐已停止（资源已释放）")

    def set_volume(self, scene, volume):
        """设置音量（手机端实时生效，范围限制0-1）"""
        if scene not in VOLUME_CONFIG:
            print(f"⚠️  未知场景：{scene}，无法设置音量")
            return

        # 音量范围校验
        volume = max(0.0, min(1.0, volume))
        VOLUME_CONFIG[scene] = volume

        # 实时更新当前播放的音频音量
        if self.current_scene == scene and self.current_sound:
            self.current_sound.volume = volume

        print(f"🔊 {scene}场景音量已设为：{round(volume * 100, 1)}%")


# 全局实例化（所有页面直接调用）
kivy_audio_player = KivyAudioPlayer()

# 兼容旧调用（无需修改其他页面）
read_text = read_toggle