import os
import sys
import random
from kivy.uix.screenmanager import Screen
from kivy.uix.label import Label
from kivy.uix.button import Button
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.image import Image
from kivy.graphics import Color, Rectangle
from kivy.core.window import Window
from kivy.properties import BooleanProperty, StringProperty, ObjectProperty
from kivy.clock import Clock
from kivy.animation import Animation

# 核心修改：导入kivy_audio（移除pygame）
from kivy_audio import kivy_audio_player
from kivy.core.audio import SoundLoader

# 从kivy_ui包内导入
from kivy_ui.left_widget import MainWithLeftWidget


# 音频逻辑：改用kivy_audio实现随机切歌+停3秒（完全兼容手机）
class AudioPlayer:
    _instance = None

    def __new__(cls):
        if cls._instance is None:
            cls._instance = super().__new__(cls)
            cls._instance.current_music = None
            cls._instance.music_list = []
            cls._instance.play_timer = None  # 播放计时器
            cls._instance.pause_timer = None  # 3秒暂停计时器
        return cls._instance

    def load_main_music(self):
        """加载main开头音乐（适配kivy路径）"""
        self.music_list.clear()
        BASE_DIR = getattr(sys, '_MEIPASS', os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
        music_dir = os.path.join(BASE_DIR, "resources", "audio", "bgm", "main_bg")

        if not os.path.exists(music_dir):
            os.makedirs(music_dir, exist_ok=True)
            print(f"创建音乐文件夹：{music_dir}")
            return

        # 筛选main开头的mp3
        for file in os.listdir(music_dir):
            if file.lower().startswith("main") and file.lower().endswith(".mp3"):
                self.music_list.append(os.path.join(music_dir, file))

        if self.music_list:
            random.shuffle(self.music_list)
            print(f"加载到 {len(self.music_list)} 首main开头音乐")
        else:
            print("未找到main开头的mp3文件")

    def _play_next_music(self):
        """内部方法：随机选下一首播放"""
        # 停止当前所有计时器
        if self.play_timer:
            Clock.unschedule(self.play_timer)
        if self.pause_timer:
            Clock.unschedule(self.pause_timer)

        # 停止当前音乐
        kivy_audio_player.stop_bg_music()

        # 随机选一首
        if not self.music_list:
            return
        music_path = random.choice(self.music_list)
        try:
            sound = SoundLoader.load(music_path)
            if sound:
                sound.volume = 0.5
                sound.play()
                self.current_music = music_path
                print(f"播放音乐：{os.path.basename(music_path)}")

                # 播放完停3秒再切歌
                self.play_timer = Clock.schedule_once(
                    lambda dt: self._pause_before_next(),
                    sound.length
                )
            else:
                print(f"无法加载音频：{music_path}")
                self._play_next_music()
        except Exception as e:
            print(f"播放失败：{e}")
            self._play_next_music()

    def _pause_before_next(self):
        """播放完停3秒再切歌"""
        self.pause_timer = Clock.schedule_once(
            lambda dt: self._play_next_music(),
            3  # 停3秒
        )

    def play_random_music(self):
        """启动随机播放"""
        kivy_audio_player.stop_bg_music()
        self._play_next_music()

    def switch_next_music(self):
        """手动切换下一首"""
        self._play_next_music()

    def stop_bg_music(self):
        """停止所有音乐和计时器"""
        try:
            kivy_audio_player.stop_bg_music()
            if self.play_timer:
                Clock.unschedule(self.play_timer)
                self.play_timer = None
            if self.pause_timer:
                Clock.unschedule(self.pause_timer)
                self.pause_timer = None
            self.current_music = None
            print("停止背景音乐")
        except Exception as e:
            print(f"停止音乐报错：{e}")


# 核心配置
BASE_DIR = getattr(sys, '_MEIPASS', os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
RANDOM_IMG_DIR = os.path.join(BASE_DIR, "resources", "images", "random_bg")
IMG_STAY_TIME = 6  # 图片停留6秒
ANIM_DURATION = 0.8  # 动画时长


class MainPage(Screen):
    to_login_signal = ObjectProperty(None)
    is_login = BooleanProperty(False)
    nickname = StringProperty("")

    def __init__(self, **kwargs):
        self.audio_inited = kwargs.pop('audio_inited', False)
        super().__init__(**kwargs)

        # 初始化组件
        self.audio = AudioPlayer()
        self.random_img_list = []
        self.img_widget = Image(allow_stretch=True, keep_ratio=False)
        self.img_widget.opacity = 0
        self.carousel_event = None

        # 加载图片
        self.load_main_images()

        # 左侧菜单+背景
        self.main_with_left = MainWithLeftWidget()
        with self.main_with_left.content_layout.canvas.before:
            Color(0xF0 / 255, 0xE6 / 255, 0xD2 / 255, 1)
            self.content_bg = Rectangle(size=self.main_with_left.content_layout.size,
                                        pos=self.main_with_left.content_layout.pos)
        self.main_with_left.content_layout.bind(
            size=lambda *x: setattr(self.content_bg, 'size', self.main_with_left.content_layout.size),
            pos=lambda *x: setattr(self.content_bg, 'pos', self.main_with_left.content_layout.pos)
        )

        # 绑定图片点击事件
        self.img_widget.bind(on_touch_down=self.on_main_touch)

        self.add_widget(self.main_with_left)

        # 初始渲染
        Clock.schedule_once(lambda dt: self.render_page(), 0.1)

    def load_main_images(self):
        """加载随机背景图片"""
        self.random_img_list.clear()
        if not os.path.exists(RANDOM_IMG_DIR):
            os.makedirs(RANDOM_IMG_DIR, exist_ok=True)
            print(f"创建图片目录：{RANDOM_IMG_DIR}")
            return

        # 筛选图片文件
        for file in os.listdir(RANDOM_IMG_DIR):
            if file.lower().endswith(('.jpg', '.png', '.jpeg')):
                self.random_img_list.append(os.path.join(RANDOM_IMG_DIR, file))

        # 去重+打乱
        self.random_img_list = list(set(self.random_img_list))
        random.shuffle(self.random_img_list)

        if self.random_img_list:
            print(f"加载到 {len(self.random_img_list)} 张背景图片")
        else:
            print("未找到背景图片")

    def render_page(self):
        """渲染页面（登录/游客态）"""
        self.main_with_left.content_layout.clear_widgets()
        self.main_with_left.content_layout.add_widget(self.main_with_left.menu_btn)

        if self.is_login:
            # 登录态：显示轮播图
            self.render_login_state()
        else:
            # 游客态：显示登录提示
            self.render_visitor_state()

    def render_login_state(self):
        """登录态渲染"""
        # 停止旧轮播
        if self.carousel_event:
            Clock.unschedule(self.carousel_event)

        # 添加轮播图
        self.main_with_left.content_layout.add_widget(self.img_widget)
        self.start_img_carousel()

        # 加载并播放音乐（仅首次）
        if not self.audio.music_list:
            self.audio.load_main_music()
        if self.audio.current_music is None and self.audio.music_list:
            self.audio.play_random_music()

        # 更新左侧菜单状态
        self.main_with_left.set_login_status(True, self.nickname)
        print(f"登录态渲染完成，欢迎 {self.nickname}")

    def render_visitor_state(self):
        """游客态渲染"""
        # 停止轮播和音乐
        if self.carousel_event:
            Clock.unschedule(self.carousel_event)
            self.carousel_event = None
        self.img_widget.source = ""
        self.img_widget.opacity = 0
        self.audio.stop_bg_music()

        # 显示游客提示
        visitor_layout = BoxLayout(orientation='vertical', padding=[40, 60], spacing=30)
        title = Label(
            text="当前为游客模式",
            font_name='STKaiti',
            font_size=32 if Window.width < 800 else 36,
            bold=True,
            color=(0x8B / 255, 0x45 / 255, 0x13 / 255, 1),
            halign='center'
        )
        desc = Label(
            text="""登录/注册后解锁：
- 随机古风背景轮播
- 古风音乐随机播放
- 创作打卡/个人目标定制
- 账号管理（重新注册/退出登录）

游客可使用：
- 诗词/古文/词语查询
- 高考语文赏析考点""",
            font_name='SimHei',
            font_size=16 if Window.width < 800 else 18,
            color=(0x5C / 255, 0x40 / 255, 0x33 / 255, 1),
            halign='center'
        )
        login_btn = Button(
            text="立即登录/注册",
            font_name='SimHei',
            font_size=20,
            size_hint_y=None,
            height=60,
            background_color=(0x7F / 255, 0xB7 / 255, 0x7E / 255, 0.95),
            color=(1, 1, 1, 1)
        )
        login_btn.bind(on_press=lambda x: self.to_login_signal() if self.to_login_signal else None)

        visitor_layout.add_widget(title)
        visitor_layout.add_widget(desc)
        visitor_layout.add_widget(login_btn)
        self.main_with_left.content_layout.add_widget(visitor_layout)

        # 更新左侧菜单状态
        self.main_with_left.set_login_status(False)
        print("游客态渲染完成")

    def start_img_carousel(self, force_switch=False):
        """图片轮播（登录态）"""
        if not self.is_login or not self.random_img_list:
            self.img_widget.source = ""
            self.img_widget.opacity = 0
            return

        # 停止旧轮播
        if self.carousel_event:
            Clock.unschedule(self.carousel_event)

        # 随机选图
        img_path = random.choice(self.random_img_list)
        if os.path.exists(img_path):
            self.img_widget.source = img_path
            # 淡入动画
            anim = Animation(opacity=1, duration=ANIM_DURATION, t='out_cubic')
            anim.start(self.img_widget)
            print(f"显示图片：{os.path.basename(img_path)}")
        else:
            self.img_widget.source = ""
            self.img_widget.opacity = 0
            print(f"图片不存在：{img_path}")

        # 启动下一轮轮播
        self.carousel_event = Clock.schedule_once(
            lambda dt: self.start_img_carousel(),
            IMG_STAY_TIME
        )

    def on_main_touch(self, widget, touch):
        """图片点击事件（切换音乐+图片）"""
        if self.is_login and widget.collide_point(*touch.pos) and touch.is_touch:
            # 切换图片
            self.start_img_carousel(force_switch=True)
            # 切换音乐
            self.audio.switch_next_music()

    def stop_play(self):
        """终极停止：清除所有计时器+停止音频+清空图片"""
        # 1. 清除所有轮播计时器
        Clock.unschedule(self.start_img_carousel)
        if self.carousel_event:
            Clock.unschedule(self.carousel_event)
            self.carousel_event = None

        # 2. 停止音频计时器
        if self.audio.play_timer:
            Clock.unschedule(self.audio.play_timer)
            self.audio.play_timer = None
        if self.audio.pause_timer:
            Clock.unschedule(self.audio.pause_timer)
            self.audio.pause_timer = None

        # 3. 清空图片
        self.img_widget.source = ""
        self.img_widget.opacity = 0
        if self.img_widget.parent:
            self.img_widget.parent.remove_widget(self.img_widget)

        # 4. 停止音频
        self.audio.stop_bg_music()
        kivy_audio_player.stop_bg_music()

    def on_enter(self):
        """进入页面"""
        if hasattr(self.manager, 'has_logined'):
            self.is_login = self.manager.has_logined
            self.nickname = self.manager.logined_user if hasattr(self.manager, 'logined_user') else ""
        print(f"进入主页面，登录状态：{self.is_login}")
        Clock.schedule_once(lambda dt: self.render_page(), 0.5)
        if not self.audio.music_list:
            self.audio.load_main_music()

    def on_leave(self):
        """离开页面"""
        self.stop_play()
        print("离开主页面，已停止所有播放")

    def on_is_login(self, instance, value):
        """登录状态变化"""
        self.render_page()


# 测试代码
if __name__ == '__main__':
    from kivy.app import App
    from kivy.core.text import LabelBase
    from kivy.uix.screenmanager import ScreenManager

    # 注册字体
    LabelBase.register(name='STKaiti', fn_regular='stkaiti.ttf')
    LabelBase.register(name='SimHei', fn_regular='simhei.ttf')


    class TestApp(App):
        def build(self):
            sm = ScreenManager()
            main_page = MainPage(name='main')
            main_page.is_login = True
            main_page.nickname = "测试用户"
            sm.add_widget(main_page)
            return sm


    TestApp().run()