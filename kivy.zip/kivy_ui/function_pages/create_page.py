from kivy.uix.boxlayout import BoxLayout
from kivy.uix.textinput import TextInput
from kivy.uix.spinner import Spinner
from kivy.uix.button import Button
from kivy.uix.label import Label
from kivy.uix.popup import Popup
from kivy.graphics import Color, Rectangle
from kivy.uix.scrollview import ScrollView
from kivy.clock import Clock
from kivy_ui.function_pages.base_function_page import BaseFunctionPage
from kivy_data import kivy_text_processor
import time


class CreatePage(BaseFunctionPage):
    """创作专区（手机端适配版）"""

    def __init__(self, username="", is_login=False, **kwargs):
        super().__init__("创作专区", username, is_login, **kwargs)
        # 1. 提前初始化所有属性，避免属性不存在异常
        self.is_operating = False
        self.result_popup = None
        self.record_popup = None
        self.type_spinner_border = None
        self.genre_spinner_border = None
        self.sub_genre_spinner_border = None
        self.create_type_combo = None
        self.create_genre_combo = None
        self.create_sub_genre_combo = None
        self.create_keyword_edit = None  # 核心：提前初始化，避免访问异常
        self.create_btn = None
        self.create_result_edit = None
        self.save_btn = None

        # 2. 延迟加载UI，避免初始化顺序问题
        Clock.schedule_once(lambda dt: self.load_func_ui(), 0.01)

    def load_func_ui(self):
        """加载创作功能UI（修复所有渲染/属性异常）"""
        self.main_layout = BoxLayout(orientation='vertical', padding=15, spacing=15)
        self.add_widget(self.main_layout)

        # 1. 二级联动选择布局
        choose_layout = BoxLayout(orientation='horizontal', spacing=10, size_hint_y=None, height=100)
        choose_layout.bind(minimum_height=choose_layout.setter('height'))

        # 输入类型选择
        type_label = Label(text="输入类型：", font_name='STKaiti', font_size=16,
                           color=(139 / 255, 69 / 255, 19 / 255, 1), size_hint_x=0.3)
        self.create_type_combo = Spinner(
            text="关键词", values=["关键词", "图片"],
            font_name='STKaiti', font_size=14,
            size_hint_x=0.7, background_color=(255 / 255, 255 / 255, 255 / 255, 0.8),
            color=(139 / 255, 69 / 255, 19 / 255, 1),
            background_normal='', background_down=''
        )
        # 修复：Spinner边框绘制（延迟绑定避免pos/size异常）
        Clock.schedule_once(lambda dt: self._draw_spinner_border(self.create_type_combo, 'type'), 0.1)
        self.create_type_combo.bind(
            text=self._on_type_change
        )
        choose_layout.add_widget(type_label)
        choose_layout.add_widget(self.create_type_combo)

        # 生成大类选择
        genre_label = Label(text="生成大类：", font_name='STKaiti', font_size=16,
                            color=(139 / 255, 69 / 255, 19 / 255, 1), size_hint_x=0.3)
        self.create_genre_combo = Spinner(
            text="诗词", values=["诗词", "短文"],
            font_name='STKaiti', font_size=14,
            size_hint_x=0.7, background_color=(255 / 255, 255 / 255, 255 / 255, 0.8),
            color=(139 / 255, 69 / 255, 19 / 255, 1),
            background_normal='', background_down=''
        )
        Clock.schedule_once(lambda dt: self._draw_spinner_border(self.create_genre_combo, 'genre'), 0.1)
        self.create_genre_combo.bind(
            text=self._on_genre_change
        )
        choose_layout.add_widget(genre_label)
        choose_layout.add_widget(self.create_genre_combo)

        # 细分体裁选择
        sub_genre_label = Label(text="细分体裁：", font_name='STKaiti', font_size=16,
                                color=(139 / 255, 69 / 255, 19 / 255, 1), size_hint_x=0.3)
        self.create_sub_genre_combo = Spinner(
            font_name='STKaiti', font_size=14,
            size_hint_x=0.7, background_color=(255 / 255, 255 / 255, 255 / 255, 0.8),
            color=(139 / 255, 69 / 255, 19 / 255, 1),
            background_normal='', background_down=''
        )
        Clock.schedule_once(lambda dt: self._draw_spinner_border(self.create_sub_genre_combo, 'sub_genre'), 0.1)
        self.create_sub_genre_combo.bind(
            text=self._on_sub_genre_change
        )
        self._update_sub_genre("诗词")
        choose_layout.add_widget(sub_genre_label)
        choose_layout.add_widget(self.create_sub_genre_combo)

        self.main_layout.add_widget(choose_layout)

        # 2. 创作灵感输入（核心：确保create_keyword_edit正确初始化）
        keyword_layout = BoxLayout(orientation='horizontal', spacing=10, size_hint_y=None, height=120)
        keyword_label = Label(text="创作灵感：", font_name='STKaiti', font_size=16,
                              color=(139 / 255, 69 / 255, 19 / 255, 1), size_hint_x=0.3)
        self.create_keyword_edit = TextInput(
            font_name='STKaiti', font_size=14,
            background_color=(255 / 255, 255 / 255, 255 / 255, 0.8),
            foreground_color=(139 / 255, 69 / 255, 19 / 255, 1),
            hint_text="输入1-3个核心关键词，如：明月、相思、江南",
            size_hint_x=0.6, multiline=True
        )
        clear_btn = Button(
            text="清空", font_name='STKaiti', font_size=12,
            background_color=(139 / 255, 69 / 255, 19 / 255, 0.7),
            color=(1, 1, 1, 1), size_hint_x=0.1
        )
        clear_btn.bind(on_press=self._clear_input)
        keyword_layout.add_widget(keyword_label)
        keyword_layout.add_widget(self.create_keyword_edit)
        keyword_layout.add_widget(clear_btn)
        self.main_layout.add_widget(keyword_layout)

        # 3. 创作+记录按钮组
        main_btn_layout = BoxLayout(orientation='horizontal', spacing=20, size_hint_y=None, height=50)
        record_btn = Button(
            text="创作记录", font_name='STKaiti', font_size=16,
            background_color=(205 / 255, 133 / 255, 63 / 255, 0.8),
            color=(1, 1, 1, 1), disabled=not self.is_login
        )
        record_btn.bind(on_press=self.on_check_record)
        self.create_btn = Button(
            text="开始创作", font_name='STKaiti', font_size=16,
            background_color=(139 / 255, 69 / 255, 19 / 255, 0.8),
            color=(1, 1, 1, 1)
        )
        self.create_btn.bind(on_press=self.on_create)
        main_btn_layout.add_widget(record_btn)
        main_btn_layout.add_widget(self.create_btn)
        self.main_layout.add_widget(main_btn_layout)

        # 4. 创作结果展示
        self.create_result_edit = TextInput(
            font_name='STKaiti', font_size=16,
            background_color=(255 / 255, 252 / 255, 245 / 255, 0.9),
            foreground_color=(139 / 255, 69 / 255, 19 / 255, 1),
            readonly=True, multiline=True,
            size_hint_y=0.4
        )
        self.main_layout.add_widget(self.create_result_edit)

        # 5. 功能按钮组
        func_btn_layout = BoxLayout(orientation='horizontal', spacing=10, size_hint_y=None, height=50)
        enlarge_btn = Button(
            text="放大查看", font_name='STKaiti', font_size=16,
            background_color=(139 / 255, 69 / 255, 19 / 255, 0.8),
            color=(1, 1, 1, 1)
        )
        enlarge_btn.bind(on_press=self._force_show_enlarge_dialog)
        self.save_btn = Button(
            text="保存创作", font_name='STKaiti', font_size=16,
            background_color=(77 / 255, 125 / 255, 76 / 255, 0.8),
            color=(1, 1, 1, 1), disabled=True
        )
        self.save_btn.bind(on_press=self.on_save_create)
        func_btn_layout.add_widget(enlarge_btn)
        func_btn_layout.add_widget(self.save_btn)
        self.main_layout.add_widget(func_btn_layout)

    def _draw_spinner_border(self, spinner, border_type):
        """延迟绘制Spinner边框，避免pos/size初始化异常"""
        with spinner.canvas.before:
            Color(222 / 255, 184 / 255, 135 / 255, 1)
            if border_type == 'type':
                self.type_spinner_border = Rectangle(pos=spinner.pos, size=spinner.size)
                spinner.bind(
                    pos=lambda _, v: setattr(self.type_spinner_border, 'pos', v),
                    size=lambda _, v: setattr(self.type_spinner_border, 'size', v)
                )
            elif border_type == 'genre':
                self.genre_spinner_border = Rectangle(pos=spinner.pos, size=spinner.size)
                spinner.bind(
                    pos=lambda _, v: setattr(self.genre_spinner_border, 'pos', v),
                    size=lambda _, v: setattr(self.genre_spinner_border, 'size', v)
                )
            elif border_type == 'sub_genre':
                self.sub_genre_spinner_border = Rectangle(pos=spinner.pos, size=spinner.size)
                spinner.bind(
                    pos=lambda _, v: setattr(self.sub_genre_spinner_border, 'pos', v),
                    size=lambda _, v: setattr(self.sub_genre_spinner_border, 'size', v)
                )

    # 新增：清空输入框方法
    def _clear_input(self, instance):
        if hasattr(self, 'create_keyword_edit') and self.create_keyword_edit:
            self.create_keyword_edit.text = ""

    # 新增：输入类型变化处理方法
    def _on_type_change(self, instance, text):
        self._update_placeholder(text)
        self._reset_create_state()

    # 新增：生成大类变化处理方法
    def _on_genre_change(self, instance, genre):
        self._update_sub_genre(genre)
        self._reset_create_state()

    # 新增：细分体裁变化处理方法
    def _on_sub_genre_change(self, instance, sub_genre):
        self._reset_create_state()

    def _update_sub_genre(self, genre):
        """二级联动更新细分体裁"""
        if genre == "诗词":
            self.create_sub_genre_combo.values = ["五言绝句", "七言绝句", "古风短诗"]
        else:
            self.create_sub_genre_combo.values = ["古风随笔", "写景散文", "抒情短文"]
        self.create_sub_genre_combo.text = self.create_sub_genre_combo.values[0]

    def _update_placeholder(self, create_type):
        """更新输入框占位符"""
        if not hasattr(self, 'create_keyword_edit'):
            return
        if create_type == "关键词":
            self.create_keyword_edit.hint_text = "输入1-3个核心关键词，如：明月、相思、江南"
        else:
            self.create_keyword_edit.hint_text = "输入图片场景描述，如：江边落日，孤舟归帆"

    def _reset_create_state(self):
        """重置创作状态（增加属性存在性校验）"""
        if hasattr(self, 'create_keyword_edit') and self.create_keyword_edit:
            self.create_keyword_edit.text = ""
        if hasattr(self, 'create_result_edit') and self.create_result_edit:
            self.create_result_edit.text = ""
        if hasattr(self, 'save_btn') and self.save_btn:
            self.save_btn.disabled = True

    def on_create(self, instance):
        """开始创作（全量异常捕获+属性校验）"""
        if self.is_operating or not self.is_login:
            return
        # 核心：校验所有关键属性是否存在
        if not hasattr(self, 'create_type_combo') or not hasattr(self, 'create_genre_combo') or \
                not hasattr(self, 'create_sub_genre_combo') or not hasattr(self, 'create_keyword_edit'):
            self._show_popup("错误", "页面初始化未完成，请重试！")
            return

        create_type = self.create_type_combo.text
        create_genre = self.create_genre_combo.text
        create_sub_genre = self.create_sub_genre_combo.text
        keyword = self.create_keyword_edit.text.strip()

        if not keyword:
            self._show_popup("提示", "请输入创作灵感！")
            return
        if create_type == "关键词" and (len(keyword) < 1 or len(keyword) > 10):
            self._show_popup("提示", "关键词类型请输入1-10个字符！")
            return
        if create_type == "图片" and (len(keyword) < 10 or len(keyword) > 200):
            self._show_popup("提示", "图片描述请输入10-200个字符！")
            return

        # 创作中状态
        self.is_operating = True
        self.create_btn.text = "创作中..."
        self.create_btn.disabled = True

        Clock.schedule_once(lambda dt: self._do_create(create_type, create_genre, create_sub_genre, keyword), 0.1)

    def _do_create(self, create_type, create_genre, create_sub_genre, keyword):
        """执行创作逻辑（异常捕获+状态重置）"""
        try:
            result = kivy_text_processor.create_content(create_type, create_genre, create_sub_genre, keyword)
            if result.strip():
                self.create_result_edit.text = result
                self.save_btn.disabled = False
            else:
                self.create_result_edit.text = f"暂无创作结果，可更换{create_type}重试～"
        except Exception as e:
            self._show_popup("错误", f"创作失败：{str(e)}")
        finally:
            self.create_btn.text = "开始创作"
            self.create_btn.disabled = False
            self.is_operating = False

    def on_save_create(self, instance):
        """保存创作结果（属性校验+异常捕获）"""
        if not self.is_login or not hasattr(self, 'create_result_edit') or not self.create_result_edit.text.strip():
            return

        try:
            create_info = {
                "username": self.username,
                "create_time": time.strftime("%Y-%m-%d %H:%M:%S", time.localtime()),
                "create_type": self.create_type_combo.text,
                "create_genre": self.create_genre_combo.text,
                "create_sub_genre": self.create_sub_genre_combo.text,
                "create_inspiration": self.create_keyword_edit.text.strip(),
                "create_result": self.create_result_edit.text,
                "create_result_text": self.create_result_edit.text
            }
            kivy_text_processor.save_create_record(create_info)
            self._show_popup("保存成功", "创作结果已成功保存！\n可在「创作记录」中查看～")
        except Exception as e:
            self._show_popup("错误", f"保存失败：{str(e)}")

    def _force_show_enlarge_dialog(self, instance):
        """放大查看创作结果（属性校验+异常捕获）"""
        if not hasattr(self, 'create_result_edit') or not self.create_result_edit.text.strip():
            self._show_popup("提示", "暂无创作结果，无法放大查看！")
            return

        try:
            content = ScrollView()
            result_text = TextInput(
                text=self.create_result_edit.text,
                font_name='STKaiti', font_size=16,
                background_color=(255 / 255, 252 / 255, 245 / 255, 0.9),
                foreground_color=(139 / 255, 69 / 255, 19 / 255, 1),
                readonly=True, multiline=True
            )
            content.add_widget(result_text)

            self.result_popup = Popup(
                title="创作结果 - 放大查看", content=content,
                size_hint=(0.9, 0.8), auto_dismiss=True
            )
            self.result_popup.open()
        except Exception as e:
            self._show_popup("错误", f"放大查看失败：{str(e)}")

    def on_check_record(self, instance):
        """查看创作记录（登录校验+异常捕获）"""
        if not self.is_login:
            self._show_popup("提示", "请先登录后查询创作记录！")
            return

        try:
            total_count, records = kivy_text_processor.get_create_records(self.username)
            if total_count == 0:
                self._show_popup("我的创作记录", f"{self.username}，你暂无创作记录～\n赶紧创作开启你的文思之旅吧！")
                return

            record_content = f"📋 {self.username} 的创作记录\n📊 总创作次数：{total_count}次\n——————————————————\n"
            for idx, record in enumerate(records, 1):
                record_content += f"{idx}. 创作时间：{record.get('create_time', '未知时间')}\n"
                record_content += f"   输入类型：{record.get('create_type', '关键词')}\n"
                record_content += f"   生成类型：{record.get('create_genre', '诗词')}-{record.get('create_sub_genre', '五言绝句')}\n"
                record_content += f"   创作灵感：{record.get('create_inspiration', '——')}\n"
                record_content += f"   结果预览：{record.get('create_result_text', '——')}\n"
                record_content += "——————————————————\n"

            content = ScrollView()
            record_text = TextInput(
                text=record_content,
                font_name='STKaiti', font_size=15,
                background_color=(255 / 255, 252 / 255, 245 / 255, 0.9),
                foreground_color=(139 / 255, 69 / 255, 19 / 255, 1),
                readonly=True, multiline=True
            )
            content.add_widget(record_text)

            self.record_popup = Popup(
                title="我的创作记录", content=content,
                size_hint=(0.9, 0.8), auto_dismiss=True
            )
            self.record_popup.open()
        except Exception as e:
            self._show_popup("错误", f"查询记录失败：{str(e)}")

    def _show_popup(self, title, text):
        """显示提示弹窗（修复Label居中）"""
        content = Label(
            text=text, font_name='STKaiti', font_size=16,
            color=(139 / 255, 69 / 255, 19 / 255, 1),
            halign='center', valign='middle'
        )
        content.bind(size=content.setter('text_size'))
        popup = Popup(
            title=title, content=content,
            size_hint=(0.7, 0.4), auto_dismiss=True
        )
        popup.open()