from kivy.uix.button import Button
from kivy.uix.textinput import TextInput
from kivy.uix.spinner import Spinner
from kivy.uix.popup import Popup
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.label import Label
from .base_function_page import BaseFunctionPage  # 继承通用基类
# 核心修改：导入真实的kivy_text_processor
from kivy_data import kivy_text_processor

# 模拟音频播放（和诗词页一致，后续对接真实audio逻辑）
def read_toggle(text):
    print(f"开始朗读：{text}")

def stop_read():
    print("停止朗读")

class ProsePage(BaseFunctionPage):  # 继承通用基类
    """Kivy版古文专区（复用基类通用逻辑，对齐电脑端+诗词页样式/功能）"""
    def __init__(self, username="", is_login=False, **kwargs):
        # 调用基类初始化（传入功能名、登录状态）
        super().__init__(func_name="古文专区", username=username, is_login=is_login, **kwargs)
        # 加载古文页专属UI（核心：只写差异化逻辑）
        self.load_func_ui()

        # 放大弹窗（和诗词页一致）
        self.enlarge_popup = None
        self.enlarge_text = TextInput(
            readonly=True,
            multiline=True,
            font_name='STKaiti',
            font_size=16,
            background_color=(255/255, 252/255, 245/255, 0.9),
            foreground_color=(92/255, 64/255, 51/255, 1)
        )

    def load_func_ui(self):
        """古文页专属UI（对齐电脑端结构：查询全部+示例+查询区+结果区）"""
        # 1. 查询全部按钮（电脑端标题右侧按钮，手机端居中）
        self._add_query_all_btn()
        # 2. 示例古文+朗读/停止按钮（对齐电脑端示例内容）
        self._add_demo_layout()
        # 3. 查询区（对齐电脑端查询类型/关键词/按钮样式）
        self._add_query_layout()
        # 4. 结果区+功能按钮（朗读/停止/放大，和诗词页一致）
        self._add_result_layout()

    def _add_query_all_btn(self):
        """查询全部按钮（专属，对齐电脑端样式）"""
        query_all_btn = Button(
            text="查询全部",
            font_name='SimHei',
            font_size=13,
            size_hint=(None, None),
            size=(90, 32),
            background_color=(139/255, 69/255, 19/255, 0.8),
            color=(1, 1, 1, 1),
            pos_hint={'center_x': 0.5}
        )
        query_all_btn.bind(on_press=lambda x: self.on_query_all())
        self.add_widget(query_all_btn)

    def _add_demo_layout(self):
        """示例古文+朗读/停止按钮（专属，电脑端同款示例内容）"""
        demo_text = """《桃花源记（节选）》
陶渊明
晋太元中，武陵人捕鱼为业。缘溪行，忘路之远近。
忽逢桃花林，夹岸数百步，中无杂树，芳草鲜美，落英缤纷。
渔人甚异之，复前行，欲穷其林。

《陋室铭》
刘禹锡
山不在高，有仙则名。水不在深，有龙则灵。
斯是陋室，惟吾德馨。苔痕上阶绿，草色入帘青。
谈笑有鸿儒，往来无白丁。可以调素琴，阅金经。
无丝竹之乱耳，无案牍之劳形。南阳诸葛庐，西蜀子云亭。
孔子云：何陋之有？"""
        demo_label = Label(
            text=demo_text,
            font_name='STKaiti',
            font_size=13,
            color=(139/255, 69/255, 19/255, 1),
            halign='center',
            size_hint=(1, None),
            height=200  # 适配古文内容长度
        )
        self.add_widget(demo_label)

        # 朗读/停止按钮（和诗词页样式完全一致）
        demo_btn_layout = BoxLayout(orientation='horizontal', spacing=10, size_hint=(1, None), height=40)
        demo_btn_layout.add_widget(Label())
        read_demo_btn = Button(text="朗读示例", font_name='SimHei', font_size=13, size_hint=(None, None), size=(90, 32),
                               background_color=(139/255, 69/255, 19/255, 0.8), color=(1,1,1,1))
        read_demo_btn.bind(on_press=lambda x: read_toggle(demo_text))
        stop_demo_btn = Button(text="停止朗读", font_name='SimHei', font_size=13, size_hint=(None, None), size=(90, 32),
                               background_color=(139/255, 69/255, 19/255, 0.8), color=(1,1,1,1))
        stop_demo_btn.bind(on_press=lambda x: stop_read())
        demo_btn_layout.add_widget(read_demo_btn)
        demo_btn_layout.add_widget(stop_demo_btn)
        demo_btn_layout.add_widget(Label())
        self.add_widget(demo_btn_layout)

    def _add_query_layout(self):
        """查询类型+关键词+查询按钮（专属，对齐电脑端/诗词页样式）"""
        # 查询类型（和诗词页一致，选项对齐电脑端）
        type_layout = BoxLayout(orientation='horizontal', spacing=10, size_hint=(1, None), height=50)
        type_layout.add_widget(Label(text="古文查询：", font_name='STKaiti', font_size=18, color=(92/255,64/255,51/255,1),
                                     size_hint=(None, None), size=(90, 40)))
        self.query_type_spinner = Spinner(text="名字", values=["名字", "图片", "关键词"], font_name='STKaiti', font_size=16,
                                          size_hint=(1, 1), background_color=(1,1,1,0.8), color=(92/255,64/255,51/255,1))
        type_layout.add_widget(self.query_type_spinner)
        self.add_widget(type_layout)

        # 关键词输入（和诗词页样式完全一致）
        keyword_layout = BoxLayout(orientation='horizontal', spacing=10, size_hint=(1, None), height=50)
        keyword_layout.add_widget(Label(text="关键词：", font_name='STKaiti', font_size=18, color=(92/255,64/255,51/255,1),
                                        size_hint=(None, None), size=(90, 40)))
        self.query_keyword_input = TextInput(hint_text="输入古文名称/关键词/图片描述", font_name='STKaiti', font_size=16,
                                             background_color=(1,1,1,0.8), foreground_color=(92/255,64/255,51/255,1),
                                             size_hint=(1, 1))
        keyword_layout.add_widget(self.query_keyword_input)
        self.add_widget(keyword_layout)

        # 查询按钮（和诗词页样式完全一致）
        query_btn = Button(text="开始查询", font_name='SimHei', font_size=18, size_hint=(None, None), size=(140, 45),
                           background_color=(139/255, 69/255, 19/255, 0.8), color=(1,1,1,1), pos_hint={'center_x': 0.5})
        query_btn.bind(on_press=lambda x: self.on_query())
        self.add_widget(query_btn)

    def _add_result_layout(self):
        """结果文本框+朗读/停止/放大按钮（专属，和诗词页样式完全一致）"""
        self.query_result_area = TextInput(readonly=True, multiline=True, font_name='STKaiti', font_size=16,
                                          background_color=(255/255,252/255,245/255,0.9),
                                          foreground_color=(92/255,64/255,51/255,1), size_hint=(1, 2))
        self.add_widget(self.query_result_area)

        # 功能按钮（和诗词页样式完全一致）
        btn_layout = BoxLayout(orientation='horizontal', spacing=10, size_hint=(1, None), height=50)
        btn_layout.add_widget(Label())
        read_btn = Button(text="朗读结果", font_name='SimHei', font_size=16, size_hint=(None, None), size=(120, 40),
                          background_color=(139/255,69/255,19/255,0.8), color=(1,1,1,1))
        read_btn.bind(on_press=lambda x: read_toggle(self.query_result_area.text))
        stop_btn = Button(text="停止朗读", font_name='SimHei', font_size=16, size_hint=(None, None), size=(120, 40),
                          background_color=(139/255,69/255,19/255,0.8), color=(1,1,1,1))
        stop_btn.bind(on_press=lambda x: stop_read())
        enlarge_btn = Button(text="放大查看", font_name='SimHei', font_size=16, size_hint=(None, None), size=(120, 40),
                             background_color=(139/255,69/255,19/255,0.8), color=(1,1,1,1))
        enlarge_btn.bind(on_press=lambda x: self.show_enlarge_popup())
        btn_layout.add_widget(read_btn)
        btn_layout.add_widget(stop_btn)
        btn_layout.add_widget(enlarge_btn)
        btn_layout.add_widget(Label())
        self.add_widget(btn_layout)

    def on_query_all(self):
        """查询全部逻辑（专属，对接古文content_type）"""
        try:
            # 核心修改：替换为真实的kivy_text_processor
            result = kivy_text_processor.query_content(query_type="all", keyword="", content_type="prose")
            self.query_result_area.text = result
        except Exception as e:
            self.query_result_area.text = f"查询全部失败：{str(e)}"

    def on_query(self):
        """关键词查询逻辑（专属，对接古文content_type）"""
        query_type = self.query_type_spinner.text
        keyword = self.query_keyword_input.text.strip()
        if not keyword:
            self.query_result_area.text = "请输入查询关键词！"
            return
        try:
            # 核心修改：替换为真实的kivy_text_processor
            result = kivy_text_processor.query_content(query_type, keyword, content_type="prose")
            self.query_result_area.text = result
        except Exception as e:
            self.query_result_area.text = f"查询失败：{str(e)}"

    def show_enlarge_popup(self):
        """放大查看弹窗（和诗词页逻辑完全一致）"""
        if not self.enlarge_popup:
            popup_layout = BoxLayout(orientation='vertical', padding=15, spacing=10)
            self.enlarge_text.text = self.query_result_area.text
            popup_layout.add_widget(self.enlarge_text)

            popup_btn_layout = BoxLayout(orientation='horizontal', spacing=10, size_hint=(1, None), height=50)
            popup_btn_layout.add_widget(Label())
            popup_read_btn = Button(text="朗读弹窗内容", font_name='SimHei', font_size=16, size_hint=(None, None), size=(140, 40),
                                    background_color=(139/255,69/255,19/255,0.8), color=(1,1,1,1))
            popup_read_btn.bind(on_press=lambda x: read_toggle(self.enlarge_text.text))
            popup_stop_btn = Button(text="停止朗读", font_name='SimHei', font_size=16, size_hint=(None, None), size=(120, 40),
                                    background_color=(139/255,69/255,19/255,0.8), color=(1,1,1,1))
            popup_stop_btn.bind(on_press=lambda x: stop_read())
            popup_btn_layout.add_widget(popup_read_btn)
            popup_btn_layout.add_widget(popup_stop_btn)
            popup_btn_layout.add_widget(Label())
            popup_layout.add_widget(popup_btn_layout)

            self.enlarge_popup = Popup(title="古文查询结果 - 放大查看", content=popup_layout, size_hint=(0.9, 0.8), auto_dismiss=True)
        else:
            self.enlarge_text.text = self.query_result_area.text
        self.enlarge_popup.open()