# kivy_ui/function_pages/appr_character.py
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.label import Label
from kivy.uix.button import Button
from kivy.uix.textinput import TextInput
from kivy.uix.popup import Popup
from kivy.properties import BooleanProperty
from kivy.core.text import LabelBase

# 继承通用基类
from .base_function_page import BaseFunctionPage
# 导入手机端数据处理层
from kivy_data import kivy_text_processor

# 注册字体（和诗词页保持一致）
LabelBase.register(name='STKaiti', fn_regular='stkaiti.ttf')
LabelBase.register(name='SimHei', fn_regular='simhei.ttf')


class ApprCharacterPage(BaseFunctionPage):
    """Kivy版人物形象赏析专区（参考诗词页样式，修复输入框可见性）"""
    enlarge_btn_enabled = BooleanProperty(False)  # 放大按钮可用状态

    def __init__(self, username="", is_login=False, **kwargs):
        # 调用基类初始化（传入功能名、登录状态）
        super().__init__(func_name="人物形象赏析", username=username, is_login=is_login, **kwargs)
        # 放大弹窗相关变量
        self.enlarge_popup = None
        self.enlarge_result_text = None
        # 加载专属UI
        self.load_func_ui()

    def load_func_ui(self):
        """人物形象赏析专属UI（参考诗词页布局，优化输入框可见性）"""
        # 1. 标题提示
        self._add_tip_label()
        # 2. 赏析文本输入区（核心优化：参考诗词页输入框样式）
        self._add_input_layout()
        # 3. 开始赏析按钮
        self._add_appreciate_btn()
        # 4. 赏析结果展示区（参考诗词页结果框样式）
        self._add_result_layout()
        # 5. 放大查看按钮（参考诗词页弹窗逻辑）
        self._add_enlarge_btn()

    def _add_tip_label(self):
        """添加提示标题（简化样式，和诗词页统一）"""
        tip_label = Label(
            text=f"🔍 人物形象赏析专区",
            font_name='STKaiti',
            font_size=18,
            color=(139 / 255, 69 / 255, 19 / 255, 1),
            halign='center',
            size_hint=(1, None),
            height=45
        )
        self.add_widget(tip_label)
        self.add_widget(Label(size_hint=(1, None), height=10))  # 间距

    def _add_input_layout(self):
        """赏析文本输入区（核心修复：完全参考诗词页输入框样式）"""
        # 输入布局（和诗词页一致的水平布局）
        input_layout = BoxLayout(orientation='horizontal', spacing=10, size_hint=(1, None), height=50)
        input_layout.add_widget(Label(
            text="赏析文本：",
            font_name='STKaiti',
            font_size=18,
            color=(92 / 255, 64 / 255, 51 / 255, 1),
            size_hint=(None, None),
            size=(90, 40)
        ))

        # 文本输入框（完全复用诗词页的配色和样式，保证文字清晰）
        self.appreciate_text_input = TextInput(
            hint_text="输入诗词/古文/现代文，自动分析人物形象",
            font_name='STKaiti',
            font_size=16,
            multiline=True,  # 改为多行，适配长文本输入
            size_hint=(1, 1),
            height=180,  # 增加输入框高度
            background_color=(1, 1, 1, 0.8),  # 浅白色背景（诗词页同款）
            foreground_color=(92 / 255, 64 / 255, 51 / 255, 1),  # 深棕色文字（诗词页同款）
            hint_text_color=(139 / 255, 139 / 255, 139 / 255, 0.8)  # 提示文字浅灰色
        )
        input_layout.add_widget(self.appreciate_text_input)

        # 单独添加多行输入框（解决水平布局高度问题）
        self.add_widget(input_layout)
        # 补充多行输入区域（核心：足够的高度+清晰的配色）
        self.appreciate_text_input_multi = TextInput(
            hint_text="（可输入多行文本）",
            font_name='STKaiti',
            font_size=16,
            multiline=True,
            size_hint=(1, None),
            height=180,
            background_color=(255 / 255, 252 / 255, 245 / 255, 0.9),  # 诗词页结果框同款背景
            foreground_color=(92 / 255, 64 / 255, 51 / 255, 1),  # 深棕色文字
            hint_text_color=(139 / 255, 139 / 255, 139 / 255, 0.8)
        )
        self.add_widget(self.appreciate_text_input_multi)
        self.add_widget(Label(size_hint=(1, None), height=15))  # 间距

    def _add_appreciate_btn(self):
        """开始赏析按钮（参考诗词页按钮样式）"""
        appreciate_btn = Button(
            text="开始赏析",
            font_name='SimHei',
            font_size=18,
            size_hint=(None, None),
            size=(140, 45),  # 诗词页同款按钮尺寸
            pos_hint={'center_x': 0.5},
            background_color=(139 / 255, 69 / 255, 19 / 255, 0.8),  # 诗词页同款按钮色
            color=(1, 1, 1, 1)
        )
        appreciate_btn.bind(on_press=lambda x: self.on_appreciate())
        self.add_widget(appreciate_btn)
        self.add_widget(Label(size_hint=(1, None), height=20))  # 间距

    def _add_result_layout(self):
        """赏析结果展示区（完全复用诗词页结果框样式）"""
        # 结果区域（和诗词页一致）
        self.appreciate_result_input = TextInput(
            readonly=True,
            multiline=True,
            font_name='STKaiti',
            font_size=16,
            background_color=(255 / 255, 252 / 255, 245 / 255, 0.9),  # 诗词页同款背景
            foreground_color=(92 / 255, 64 / 255, 51 / 255, 1),  # 深棕色文字
            size_hint=(1, 2)  # 诗词页同款高度占比
        )
        self.add_widget(self.appreciate_result_input)

        # 功能按钮布局（参考诗词页：朗读/停止/放大）
        btn_layout = BoxLayout(orientation='horizontal', spacing=10, size_hint=(1, None), height=50)
        btn_layout.add_widget(Label())
        # 暂时保留放大按钮（后续可加朗读功能）
        self.enlarge_btn = Button(
            text="放大查看",
            font_name='SimHei',
            font_size=16,
            size_hint=(None, None),
            size=(120, 40),
            background_color=(139 / 255, 69 / 255, 19 / 255, 0.8),
            color=(1, 1, 1, 1),
            disabled=True  # 初始禁用
        )
        self.enlarge_btn.bind(on_press=lambda x: self.show_enlarge_popup())
        btn_layout.add_widget(self.enlarge_btn)
        btn_layout.add_widget(Label())
        self.add_widget(btn_layout)

    def _add_enlarge_btn(self):
        """兼容旧方法，实际已整合到结果布局中"""
        pass

    def show_enlarge_popup(self):
        """放大查看弹窗（完全参考诗词页逻辑）"""
        if not self.enlarge_popup:
            popup_layout = BoxLayout(orientation='vertical', padding=15, spacing=10)
            self.enlarge_result_text = TextInput(
                readonly=True,
                multiline=True,
                font_name='STKaiti',
                font_size=16,
                background_color=(255 / 255, 252 / 255, 245 / 255, 0.9),
                foreground_color=(92 / 255, 64 / 255, 51 / 255, 1)
            )
            popup_layout.add_widget(self.enlarge_result_text)
            self.enlarge_popup = Popup(
                title="人物形象赏析结果 - 放大查看",
                content=popup_layout,
                size_hint=(0.9, 0.8),  # 诗词页同款弹窗尺寸
                auto_dismiss=True
            )
        else:
            self.enlarge_result_text.text = self.appreciate_result_input.text
        self.enlarge_popup.open()

    def on_appreciate(self):
        """核心赏析逻辑（整合输入框文本）"""
        # 合并单行+多行输入框的文本（兼容两种输入方式）
        text = self.appreciate_text_input.text.strip() + "\n" + self.appreciate_text_input_multi.text.strip()
        text = text.strip()

        if not text:
            self.appreciate_result_input.text = "请输入需要赏析的文本内容！"
            return

        try:
            # 调用手机端赏析逻辑
            result = kivy_text_processor.appreciate_text(text, appr_type="character")
            self.appreciate_result_input.text = result
            # 启用放大按钮
            self.enlarge_btn.disabled = False
        except Exception as e:
            self.appreciate_result_input.text = f"赏析失败：{str(e)}"
            self.enlarge_btn.disabled = True

    def _update_enlarge_btn_style(self, enabled):
        """兼容旧方法，实际已简化样式逻辑"""
        self.enlarge_btn.disabled = not enabled
        if enabled:
            self.enlarge_btn.background_color = (139 / 255, 69 / 255, 19 / 255, 0.8)
        else:
            self.enlarge_btn.background_color = (139 / 255, 69 / 255, 19 / 255, 0.3)

    # 兼容旧方法
    def _create_enlarge_dialog(self):
        pass

    def _force_show_enlarge_dialog(self):
        self.show_enlarge_popup()