# kivy_ui/function_pages/appr_template.py
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.label import Label
from kivy.uix.button import Button
from kivy.uix.textinput import TextInput
from kivy.uix.popup import Popup
from kivy.properties import BooleanProperty
from kivy.core.text import LabelBase

# 继承通用基类
from .base_function_page import BaseFunctionPage
# 导入手机端数据处理层
from kivy_data import kivy_text_processor

# 注册字体（和项目统一）
LabelBase.register(name='STKaiti', fn_regular='stkaiti.ttf')
LabelBase.register(name='SimHei', fn_regular='simhei.ttf')


# ========== 改这里 ❌❌❌ ==========
class ApprPlotPage(BaseFunctionPage):
    """情节作用赏析专区"""  # ========== 改这里 ❌❌❌ ==========
    enlarge_btn_enabled = BooleanProperty(False)

    def __init__(self, username="", is_login=False, **kwargs):
        # ========== 改这里 ❌❌❌ ==========
        super().__init__(func_name="情节作用赏析专区", username=username, is_login=is_login, **kwargs)
        self.enlarge_popup = None
        self.enlarge_result_text = None
        self.load_func_ui()

    def load_func_ui(self):
        self._add_tip_label()
        self._add_input_layout()
        self._add_appreciate_btn()
        self._add_result_layout()
        self._add_enlarge_btn()

    def _add_tip_label(self):
        tip_label = Label(
            text=f"🔍 {self.func_name}",
            font_name='STKaiti',
            font_size=18,
            color=(139 / 255, 69 / 255, 19 / 255, 1),
            halign='center',
            size_hint=(1, None),
            height=45
        )
        self.add_widget(tip_label)
        self.add_widget(Label(size_hint=(1, None), height=10))

    def _add_input_layout(self):
        input_layout = BoxLayout(orientation='horizontal', spacing=10, size_hint=(1, None), height=50)
        input_layout.add_widget(Label(
            text="赏析文本：",
            font_name='STKaiti',
            font_size=18,
            color=(92 / 255, 64 / 255, 51 / 255, 1),
            size_hint=(None, None),
            size=(90, 40)
        ))

        self.appreciate_text_input = TextInput(
            # ========== 改这里 ❌❌❌ ==========
            hint_text="输入诗词/古文/现代文，自动分析情节作用",
            font_name='STKaiti',
            font_size=16,
            multiline=True,
            size_hint=(1, 1),
            height=180,
            background_color=(1, 1, 1, 0.8),
            foreground_color=(92 / 255, 64 / 255, 51 / 255, 1),
            hint_text_color=(139 / 255, 139 / 255, 139 / 255, 0.8)
        )
        input_layout.add_widget(self.appreciate_text_input)
        self.add_widget(input_layout)

        self.appreciate_text_input_multi = TextInput(
            hint_text="（可输入多行文本）",
            font_name='STKaiti',
            font_size=16,
            multiline=True,
            size_hint=(1, None),
            height=180,
            background_color=(255 / 255, 252 / 255, 245 / 255, 0.9),
            foreground_color=(92 / 255, 64 / 255, 51 / 255, 1),
            hint_text_color=(139 / 255, 139 / 255, 139 / 255, 0.8)
        )
        self.add_widget(self.appreciate_text_input_multi)
        self.add_widget(Label(size_hint=(1, None), height=15))

    def _add_appreciate_btn(self):
        appreciate_btn = Button(
            text="开始赏析",
            font_name='SimHei',
            font_size=18,
            size_hint=(None, None),
            size=(140, 45),
            pos_hint={'center_x': 0.5},
            background_color=(139 / 255, 69 / 255, 19 / 255, 0.8),
            color=(1, 1, 1, 1)
        )
        appreciate_btn.bind(on_press=lambda x: self.on_appreciate())
        self.add_widget(appreciate_btn)
        self.add_widget(Label(size_hint=(1, None), height=20))

    def _add_result_layout(self):
        self.appreciate_result_input = TextInput(
            readonly=True,
            multiline=True,
            font_name='STKaiti',
            font_size=16,
            background_color=(255 / 255, 252 / 255, 245 / 255, 0.9),
            foreground_color=(92 / 255, 64 / 255, 51 / 255, 1),
            size_hint=(1, 2)
        )
        self.add_widget(self.appreciate_result_input)

        btn_layout = BoxLayout(orientation='horizontal', spacing=10, size_hint=(1, None), height=50)
        btn_layout.add_widget(Label())
        self.enlarge_btn = Button(
            text="放大查看",
            font_name='SimHei',
            font_size=16,
            size_hint=(None, None),
            size=(120, 40),
            background_color=(139 / 255, 69 / 255, 19 / 255, 0.8),
            color=(1, 1, 1, 1),
            disabled=True
        )
        self.enlarge_btn.bind(on_press=lambda x: self.show_enlarge_popup())
        btn_layout.add_widget(self.enlarge_btn)
        btn_layout.add_widget(Label())
        self.add_widget(btn_layout)

    def _add_enlarge_btn(self):
        pass

    def show_enlarge_popup(self):
        if not self.enlarge_popup:
            popup_layout = BoxLayout(orientation='vertical', padding=15, spacing=10)
            self.enlarge_result_text = TextInput(
                readonly=True,
                multiline=True,
                font_name='STKaiti',
                font_size=16,
                background_color=(255 / 255, 252 / 255, 245 / 255, 0.9),
                foreground_color=(92 / 255, 64 / 255, 51 / 255, 1)
            )
            popup_layout.add_widget(self.enlarge_result_text)
            self.enlarge_popup = Popup(
                title=f"{self.func_name} - 放大查看",
                content=popup_layout,
                size_hint=(0.9, 0.8),
                auto_dismiss=True
            )
        else:
            self.enlarge_result_text.text = self.appreciate_result_input.text
        self.enlarge_popup.open()

    def on_appreciate(self):
        text = self.appreciate_text_input.text.strip() + "\n" + self.appreciate_text_input_multi.text.strip()
        text = text.strip()

        if not text:
            self.appreciate_result_input.text = "请输入需要赏析的文本内容！"
            return

        try:
            # ========== 改这里 ❌❌❌ ==========
            result = kivy_text_processor.appreciate_text(text, appr_type="plot")
            self.appreciate_result_input.text = result
            self.enlarge_btn.disabled = False
        except Exception as e:
            self.appreciate_result_input.text = f"赏析失败：{str(e)}"
            self.enlarge_btn.disabled = True

    def _update_enlarge_btn_style(self, enabled):
        self.enlarge_btn.disabled = not enabled
        if enabled:
            self.enlarge_btn.background_color = (139 / 255, 69 / 255, 19 / 255, 0.8)
        else:
            self.enlarge_btn.background_color = (139 / 255, 69 / 255, 19 / 255, 0.3)

    def _create_enlarge_dialog(self):
        pass

    def _force_show_enlarge_dialog(self):
        self.show_enlarge_popup()