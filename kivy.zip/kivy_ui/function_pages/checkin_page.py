from kivy.uix.boxlayout import BoxLayout
from kivy.uix.label import Label
from kivy.uix.button import Button
from kivy.uix.popup import Popup
from kivy.uix.scrollview import ScrollView
from kivy.uix.textinput import TextInput
from kivy.graphics import Color, Rectangle
from kivy.clock import Clock
from kivy_ui.function_pages.base_function_page import BaseFunctionPage
from kivy_data import kivy_text_processor


class CheckinPage(BaseFunctionPage):
    """每日打卡专区（手机端适配版）"""

    def __init__(self, username="", is_login=False, **kwargs):
        super().__init__("每日打卡", username, is_login, **kwargs)
        self.checkin_btn = None
        self.record_btn = None
        self.recommend_label = None
        self.checkin_result_label = None
        self.record_popup = None
        # 初始化推荐信息属性（避免后续访问报错）
        self.recommend_label_recommend_info = None
        self.load_func_ui()
        # 初始化校验今日打卡状态
        Clock.schedule_once(lambda dt: self._check_today_checkin_status(), 0.1)

    def load_func_ui(self):
        """加载打卡UI（适配手机竖屏）"""
        self.main_layout = BoxLayout(orientation='vertical', padding=30, spacing=15)
        self.add_widget(self.main_layout)

        # 1. 主标题+分割线
        main_title = Label(
            text="每日打卡", font_name='STKaiti', font_size=24,
            color=(92 / 255, 64 / 255, 51 / 255, 1), halign='center',
            size_hint_y=None, height=40
        )
        self.main_layout.add_widget(main_title)

        # 分割线 - 修复：补充pos绑定，避免坐标错误
        line_layout = BoxLayout(size_hint_y=None, height=2)
        with line_layout.canvas.before:
            Color(222 / 255, 184 / 255, 135 / 255, 1)
            self.line_rect = Rectangle(size=line_layout.size, pos=line_layout.pos)
        # 同时绑定size和pos，确保分割线位置/尺寸正确
        line_layout.bind(
            size=lambda s, v: setattr(self.line_rect, 'size', v),
            pos=lambda s, v: setattr(self.line_rect, 'pos', v)
        )
        self.main_layout.add_widget(line_layout)

        # 2. 副标题+问候语
        sub_title = Label(
            text="坚持语文学习 · 积累点滴进步 · 打卡见证成长",
            font_name='STKaiti', font_size=16, color=(139 / 255, 69 / 255, 19 / 255, 1),
            halign='center', size_hint_y=None, height=30
        )
        self.main_layout.add_widget(sub_title)

        greet_text = f"{self.username if self.username else '客官'}，今日宜打卡✨"
        greet_label = Label(
            text=greet_text, font_name='STKaiti', font_size=17,
            color=(92 / 255, 64 / 255, 51 / 255, 1), halign='center',
            size_hint_y=None, height=80
        )
        # 古风背景样式
        with greet_label.canvas.before:
            Color(222 / 255, 184 / 255, 135 / 255, 0.25)
            self.greet_rect = Rectangle(size=greet_label.size, pos=greet_label.pos)
        greet_label.bind(
            size=lambda s, v: setattr(self.greet_rect, 'size', v),
            pos=lambda s, v: setattr(self.greet_rect, 'pos', v)
        )
        self.main_layout.add_widget(greet_label)

        # 3. 功能按钮组
        btn_layout = BoxLayout(orientation='horizontal', spacing=40, size_hint_y=None, height=60)
        # 打卡按钮
        self.checkin_btn = Button(
            text="立即打卡", font_name='STKaiti', font_size=18,
            background_color=(139 / 255, 69 / 255, 19 / 255, 0.85),
            color=(1, 1, 1, 1), size_hint=(0.5, 1)
        )
        self.checkin_btn.bind(on_press=self.on_checkin)
        btn_layout.add_widget(self.checkin_btn)

        # 记录按钮
        self.record_btn = Button(
            text="打卡记录", font_name='STKaiti', font_size=18,
            background_color=(205 / 255, 133 / 255, 63 / 255, 0.85),
            color=(1, 1, 1, 1), size_hint=(0.5, 1)
        )
        self.record_btn.bind(on_press=self.on_check_record)
        btn_layout.add_widget(self.record_btn)
        self.main_layout.add_widget(btn_layout)

        # 4. 打卡结果展示
        self.checkin_result_label = Label(
            text="", font_name='STKaiti', font_size=16,
            color=(139 / 255, 69 / 255, 19 / 255, 1), halign='center',
            valign='middle', size_hint_y=0.3
        )
        # 修复：绑定text_size确保文字垂直居中
        self.checkin_result_label.bind(size=self.checkin_result_label.setter('text_size'))
        # 结果框样式
        with self.checkin_result_label.canvas.before:
            Color(255 / 255, 255 / 255, 255 / 255, 0.85)
            self.result_rect = Rectangle(size=self.checkin_result_label.size, pos=self.checkin_result_label.pos)
        self.checkin_result_label.bind(
            size=lambda s, v: setattr(self.result_rect, 'size', v),
            pos=lambda s, v: setattr(self.result_rect, 'pos', v)
        )
        self.main_layout.add_widget(self.checkin_result_label)

        # 5. 学习推荐标签（可点击）
        self.recommend_label = Label(
            text="", font_name='STKaiti', font_size=15,
            color=(210 / 255, 105 / 255, 30 / 255, 1), halign='center',
            size_hint_y=None, height=40, markup=True
        )
        # 修复：绑定text_size确保文字居中
        self.recommend_label.bind(size=self.recommend_label.setter('text_size'))
        self.recommend_label.bind(on_touch_down=self._on_jump_analyse)
        self.recommend_label.opacity = 0  # 初始隐藏
        self.main_layout.add_widget(self.recommend_label)

    def _check_today_checkin_status(self):
        """校验今日打卡状态"""
        if not self.is_login or not self.username:
            return
        try:
            is_checked, today_word, recommend_info = kivy_text_processor.check_today_checkin(self.username)
            if is_checked:
                self.checkin_btn.text = "今日已打卡"
                self.checkin_btn.disabled = True
                self.checkin_result_label.text = f"✅ 今日打卡成功！\n{today_word}"
                self._show_recommend(recommend_info)
        except Exception as e:
            # 补充异常打印，便于排查
            print(f"校验打卡状态失败：{e}")
            pass

    def on_checkin(self, instance):
        """核心打卡逻辑"""
        if not self.is_login or not self.username:
            self._show_popup("提示", "请先登录后再打卡！")
            return
        try:
            result_text, continue_days, recommend_info = kivy_text_processor.checkin(self.username)
            self.checkin_result_label.text = result_text
            self.checkin_btn.text = "今日已打卡"
            self.checkin_btn.disabled = True
            self._show_recommend(recommend_info)
            self._show_milestone_tips(continue_days)
        except Exception as e:
            self._show_popup("错误", f"打卡失败：{str(e)}")

    def _show_recommend(self, recommend_info):
        """展示学习推荐（支持点击跳转）"""
        if not recommend_info:
            return
        zone_name, article_name = recommend_info
        self.recommend_label.text = f"👉 今日推荐赏析：{article_name}【点击直达{zone_name}】"
        self.recommend_label.opacity = 1
        # 修复：改用实例属性存储，避免Label对象动态加属性报错
        self.recommend_label_recommend_info = (zone_name, article_name)

    def _show_milestone_tips(self, continue_days):
        """连续打卡里程碑彩蛋"""
        milestone_map = {
            7: "🎉 连续打卡7天！\n你已养成语文学习微习惯，继续坚持～",
            14: "🎊 连续打卡14天！\n点滴积累终有收获，语文学习贵在坚持～",
            30: "🏆 连续打卡30天！\n恭喜你完成月度打卡挑战，离高分更近一步～",
            60: "🌟 连续打卡60天！\n极致的坚持造就极致的结果，为你的毅力点赞～"
        }
        if continue_days in milestone_map:
            self._show_popup("打卡里程碑", milestone_map[continue_days])

    def _on_jump_analyse(self, instance, touch):
        """点击推荐标签跳转赏析专区 - 修复：增加属性判空"""
        if instance.collide_point(*touch.pos) and self.recommend_label_recommend_info:
            zone_name, article_name = self.recommend_label_recommend_info
            # 这里替换为你的跳转逻辑（如发送事件到主界面）
            print(f"跳转至：{zone_name} - {article_name}")

    def on_check_record(self, instance):
        """查看打卡记录"""
        if not self.is_login or not self.username:
            self._show_popup("提示", "请先登录后查询打卡记录！")
            return
        try:
            total_count, continue_days, records = kivy_text_processor.get_checkin_records(self.username)
            if total_count == 0:
                self._show_popup("我的打卡记录", f"{self.username}，你暂无打卡记录～\n赶紧打卡开启学习之旅吧！")
                return

            # 构建记录内容
            record_content = f"📋 {self.username} 的打卡记录\n"
            record_content += f"📊 总打卡：{total_count}次 | 📈 连续打卡：{continue_days}天\n"
            record_content += "——————————————————\n"
            for idx, record in enumerate(records, 1):
                record_time = record.get('checkin_time', '未知时间')
                record_word = record.get('encouragement_word', '—— 暂无寄语 ——')
                record_content += f"{idx}. 打卡时间：{record_time}\n   当日寄语：{record_word}\n\n"

            # 显示记录弹窗
            content = ScrollView()
            record_text = TextInput(
                text=record_content, font_name='STKaiti', font_size=16,
                background_color=(255 / 255, 252 / 255, 245 / 255, 0.9),
                foreground_color=(92 / 255, 64 / 255, 51 / 255, 1),
                readonly=True, multiline=True
            )
            content.add_widget(record_text)

            self.record_popup = Popup(
                title="我的打卡记录", content=content,
                size_hint=(0.9, 0.8), auto_dismiss=True
            )
            self.record_popup.open()
        except Exception as e:
            self._show_popup("错误", f"查询失败：{str(e)}")

    def _show_popup(self, title, text):
        """通用提示弹窗 - 修复：绑定text_size确保文字居中"""
        content = Label(
            text=text, font_name='STKaiti', font_size=16,
            color=(139 / 255, 69 / 255, 19 / 255, 1),
            halign='center', valign='middle'
        )
        # 核心修复：绑定text_size，否则Label文字无法垂直居中，可能引发渲染崩溃
        content.bind(size=content.setter('text_size'))
        popup = Popup(
            title=title, content=content,
            size_hint=(0.7, 0.4), auto_dismiss=True
        )
        popup.open()