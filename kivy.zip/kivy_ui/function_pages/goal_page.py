from kivy.uix.boxlayout import BoxLayout
from kivy.uix.label import Label
from kivy.uix.button import Button
from kivy.uix.textinput import TextInput
from kivy.uix.popup import Popup
from kivy.uix.scrollview import ScrollView
from kivy.graphics import Color, Rectangle
from kivy.clock import Clock
from kivy_ui.function_pages.base_function_page import BaseFunctionPage
from kivy_data import kivy_text_processor


class GoalPage(BaseFunctionPage):
    """个人目标定制专区（手机端适配版）"""

    def __init__(self, username="", is_login=False, **kwargs):
        super().__init__("个人目标定制", username, is_login, **kwargs)
        self.goal_edit = None
        self.goal_result_edit = None
        self.enlarge_btn = None
        self.result_popup = None
        self.all_goals = []
        self.recent_goal_num = 3
        self.load_func_ui()
        # 进入页面加载近期目标
        Clock.schedule_once(lambda dt: self.on_load_recent_goals(), 0.1)

    def load_func_ui(self):
        """加载目标定制UI"""
        self.main_layout = BoxLayout(orientation='vertical', padding=20, spacing=15)
        self.add_widget(self.main_layout)

        # 1. 目标输入框
        input_layout = BoxLayout(orientation='horizontal', spacing=10, size_hint_y=None, height=60)
        input_label = Label(
            text="我的目标：", font_name='STKaiti', font_size=16,
            color=(92 / 255, 64 / 255, 51 / 255, 1), size_hint_x=0.3
        )
        self.goal_edit = TextInput(
            hint_text="输入语文学习小目标（如：每天背1首古诗）",
            font_name='STKaiti', font_size=14,
            background_color=(255 / 255, 255 / 255, 255 / 255, 0.8),
            foreground_color=(92 / 255, 64 / 255, 51 / 255, 1),
            size_hint_x=0.7
        )
        # 回车保存
        self.goal_edit.bind(on_text_validate=self.on_save_goal)
        input_layout.add_widget(input_label)
        input_layout.add_widget(self.goal_edit)
        self.main_layout.add_widget(input_layout)

        # 2. 功能按钮组
        btn_layout = BoxLayout(orientation='horizontal', spacing=10, size_hint_y=None, height=50)
        # 保存目标
        save_btn = Button(
            text="保存目标", font_name='STKaiti', font_size=16,
            background_color=(139 / 255, 69 / 255, 19 / 255, 0.8),
            color=(1, 1, 1, 1), size_hint_x=0.25
        )
        save_btn.bind(on_press=self.on_save_goal)
        btn_layout.add_widget(save_btn)

        # 查看目标
        get_btn = Button(
            text="查看目标", font_name='STKaiti', font_size=16,
            background_color=(139 / 255, 69 / 255, 19 / 255, 0.8),
            color=(1, 1, 1, 1), size_hint_x=0.25
        )
        get_btn.bind(on_press=self.on_get_goal)
        btn_layout.add_widget(get_btn)

        # 标记完成
        finish_btn = Button(
            text="标记完成", font_name='STKaiti', font_size=16,
            background_color=(139 / 255, 69 / 255, 19 / 255, 0.8),
            color=(1, 1, 1, 1), size_hint_x=0.25
        )
        finish_btn.bind(on_press=self.on_mark_finish)
        btn_layout.add_widget(finish_btn)

        # 放大查看
        self.enlarge_btn = Button(
            text="放大查看", font_name='STKaiti', font_size=16,
            background_color=(139 / 255, 69 / 255, 19 / 255, 0.3),
            color=(245 / 255, 237 / 255, 224 / 255, 1),
            size_hint_x=0.25, disabled=True
        )
        self.enlarge_btn.bind(on_press=self._force_show_enlarge_dialog)
        btn_layout.add_widget(self.enlarge_btn)
        self.main_layout.add_widget(btn_layout)

        # 3. 目标展示区
        self.goal_result_edit = TextInput(
            font_name='STKaiti', font_size=16,
            background_color=(255 / 255, 255 / 255, 255 / 255, 0.8),
            foreground_color=(139 / 255, 69 / 255, 19 / 255, 1),
            readonly=True, multiline=True,
            size_hint_y=0.7
        )
        # 绑定点击标记事件
        self.goal_result_edit.bind(on_touch_down=self.on_goal_click)
        self.main_layout.add_widget(self.goal_result_edit)

    def _update_enlarge_btn_style(self, enabled):
        """更新放大按钮样式"""
        self.enlarge_btn.disabled = not enabled
        if enabled:
            self.enlarge_btn.background_color = (139 / 255, 69 / 255, 19 / 255, 0.8)
            self.enlarge_btn.color = (1, 1, 1, 1)
        else:
            self.enlarge_btn.background_color = (139 / 255, 69 / 255, 19 / 255, 0.3)
            self.enlarge_btn.color = (245 / 255, 237 / 255, 224 / 255, 1)

    def _force_show_enlarge_dialog(self, instance):
        """放大查看目标（彻底修复闪退）"""
        try:
            # 1. 基础校验
            if self.enlarge_btn.disabled or not self.goal_result_edit.text.strip():
                self._show_popup("提示", "暂无目标信息，无法放大查看！")
                return

            # 2. 安全获取texture_size，避免属性错误
            try:
                text_height = self.goal_result_edit.texture_size[1] + 40
            except (AttributeError, IndexError):
                text_height = 200  # 兜底默认高度

            # 3. ScrollView适配TextInput尺寸
            content_layout = BoxLayout(orientation='vertical', size_hint_y=None)
            content_layout.bind(minimum_height=content_layout.setter('height'))

            dialog_text = TextInput(
                text=self.goal_result_edit.text, font_name='STKaiti', font_size=18,
                background_color=(255 / 255, 252 / 255, 245 / 255, 0.9),
                foreground_color=(92 / 255, 64 / 255, 51 / 255, 1),
                readonly=True, multiline=True,
                size_hint_y=None, height=text_height
            )
            dialog_text.bind(on_touch_down=self.on_dialog_goal_click)
            content_layout.add_widget(dialog_text)

            scroll_view = ScrollView(size_hint=(1, 1))
            scroll_view.add_widget(content_layout)

            self.result_popup = Popup(
                title="个人目标 - 放大查看", content=scroll_view,
                size_hint=(0.9, 0.8), auto_dismiss=True
            )
            self.result_popup.open()
        except Exception as e:
            # 捕获所有异常，避免闪退
            self._show_popup("错误", f"放大查看失败：{str(e)}")
            print(f"放大查看目标异常：{e}")

    def on_load_recent_goals(self):
        """加载近期目标"""
        if not self.is_login or not self.username:
            self.goal_result_edit.text = "🔒 请先登录，解锁个人目标定制功能！"
            self._update_enlarge_btn_style(False)
            return
        try:
            self.all_goals = kivy_text_processor.get_all_user_goals(self.username) or []
            if not self.all_goals:
                self.goal_result_edit.text = "🎯 暂无设置目标，快来添加你的语文学习小目标吧！"
                self._update_enlarge_btn_style(False)
                return

            # 展示近期目标
            recent_goals = self.all_goals[-self.recent_goal_num:]
            recent_text = "📌 近期学习目标（点击目标自由标记/点按钮按序标记）：\n"
            for idx, (goal, is_finish) in enumerate(recent_goals, 1):
                status = "✅ 已完成" if is_finish else "🔘 未完成"
                recent_text += f"{idx}. {goal} {status}\n"
            self.goal_result_edit.text = recent_text
            self._update_enlarge_btn_style(True)
        except Exception as e:
            self.goal_result_edit.text = f"❌ 加载目标失败：{str(e)}"
            self._update_enlarge_btn_style(False)

    def on_save_goal(self, instance=None):
        """保存目标"""
        if not self.is_login or not self.username:
            self._show_popup("提示", "请先登录后再设置目标！")
            return
        goal = self.goal_edit.text.strip()
        if not goal:
            self._show_popup("提示", "请输入个人语文学习目标！")
            return
        try:
            kivy_text_processor.set_user_goal(self.username, goal, is_finish=False)
            self.goal_result_edit.foreground_color = (46 / 255, 139 / 255, 87 / 255, 1)
            self.goal_result_edit.text = f"✅ 保存成功！\n你的新目标：{goal}"
            self.goal_edit.text = ""
            self._update_enlarge_btn_style(True)
            # 刷新目标列表
            Clock.schedule_once(lambda dt: self.on_load_recent_goals(), 0.5)
        except Exception as e:
            self.goal_result_edit.foreground_color = (220 / 255, 20 / 255, 60 / 255, 1)
            self.goal_result_edit.text = f"❌ 保存失败：{str(e)}"
            self._show_popup("错误", f"保存目标失败：{str(e)}")

    def on_get_goal(self, instance):
        """查看所有目标"""
        if not self.is_login or not self.username:
            self._show_popup("提示", "请先登录后再查看目标！")
            return
        try:
            self.all_goals = kivy_text_processor.get_all_user_goals(self.username) or []
            if not self.all_goals:
                self.goal_result_edit.text = "🎯 暂无设置目标，快来添加吧！"
                self._update_enlarge_btn_style(False)
                return

            # 展示所有目标
            all_text = f"📋 所有学习目标（共{len(self.all_goals)}条，点击目标自由标记/点按钮按序标记）：\n"
            for idx, (goal, is_finish) in enumerate(reversed(self.all_goals), 1):
                status = "✅ 已完成" if is_finish else "🔘 未完成"
                all_text += f"{idx}. {goal} {status}\n"
            self.goal_result_edit.foreground_color = (139 / 255, 69 / 255, 19 / 255, 1)
            self.goal_result_edit.text = all_text
            self._update_enlarge_btn_style(True)
        except Exception as e:
            self.goal_result_edit.text = f"❌ 查看失败：{str(e)}"
            self._show_popup("错误", f"查看目标失败：{str(e)}")

    def on_mark_finish(self, instance):
        """按序标记完成"""
        if not self.is_login or not self.username:
            self._show_popup("提示", "请先登录后打卡！")
            return
        self.all_goals = kivy_text_processor.get_all_user_goals(self.username) or []
        if not self.all_goals:
            self._show_popup("提示", "暂无目标可打卡，先添加目标吧！")
            return

        # 查找最后一条未完成目标
        unfinish_goals = [idx for idx, (g, f) in enumerate(self.all_goals) if not f]
        if not unfinish_goals:
            self._show_popup("提示", "🎉 所有目标都已完成，太棒了！")
            return

        last_unfinish_idx = unfinish_goals[-1]
        self.all_goals[last_unfinish_idx] = (self.all_goals[last_unfinish_idx][0], True)
        kivy_text_processor.update_user_goals(self.username, self.all_goals)

        self._show_popup("打卡成功", f"✅ 按序完成目标：{self.all_goals[last_unfinish_idx][0]}")
        # 刷新目标展示
        current_content = self.goal_result_edit.text
        if "所有学习目标" in current_content:
            self.on_get_goal(None)
        else:
            self.on_load_recent_goals()

    def _get_click_goal_index(self, text_edit, touch):
        """获取点击的目标索引（修复索引越界）"""
        if not self.all_goals or not text_edit.collide_point(*touch.pos):
            return -1

        # 获取点击行的文本
        try:
            line_num = text_edit.get_cursor_from_xy(touch.x, touch.y)[1]
            lines = text_edit.text.split('\n')
            if line_num >= len(lines) or line_num < 0:
                return -1

            line_text = lines[line_num].strip()
            if not line_text or not line_text[0].isdigit() or '.' not in line_text:
                return -1

            # 解析行号
            click_line_num = int(line_text.split('.')[0])
            current_content = text_edit.text

            if "所有学习目标" in current_content:
                # 所有目标：倒序展示
                target_idx = len(self.all_goals) - click_line_num
            elif "近期学习目标" in current_content:
                # 近期目标：最后N条
                recent_start_idx = len(self.all_goals) - self.recent_goal_num
                target_idx = recent_start_idx + click_line_num - 1
            else:
                return -1

            # 索引边界校验
            if target_idx < 0 or target_idx >= len(self.all_goals):
                return -1
            return target_idx
        except (ValueError, IndexError, AttributeError):
            # 捕获所有异常，避免闪退
            return -1

    def on_goal_click(self, instance, touch):
        """主页面点击标记目标"""
        if touch.is_touch and touch.button == 'left' and self.is_login and self.username:
            goal_idx = self._get_click_goal_index(instance, touch)
            if goal_idx >= 0 and goal_idx < len(self.all_goals):
                goal, is_finish = self.all_goals[goal_idx]
                self.all_goals[goal_idx] = (goal, not is_finish)
                kivy_text_processor.update_user_goals(self.username, self.all_goals)

                status = "✅ 已完成" if not is_finish else "🔘 未完成"
                self._show_popup("操作成功", f"目标状态更新：{goal} → {status}")

                # 刷新展示
                current_content = instance.text
                if "所有学习目标" in current_content:
                    self.on_get_goal(None)
                else:
                    self.on_load_recent_goals()

    def on_dialog_goal_click(self, instance, touch):
        """弹窗内点击标记目标"""
        if touch.is_touch and touch.button == 'left' and self.is_login and self.username:
            goal_idx = self._get_click_goal_index(instance, touch)
            if goal_idx >= 0 and goal_idx < len(self.all_goals):
                goal, is_finish = self.all_goals[goal_idx]
                self.all_goals[goal_idx] = (goal, not is_finish)
                kivy_text_processor.update_user_goals(self.username, self.all_goals)

                status = "✅ 已完成" if not is_finish else "🔘 未完成"
                self._show_popup("操作成功", f"目标状态更新：{goal} → {status}")

                # 同步刷新
                current_content = instance.text
                if "所有学习目标" in current_content:
                    self.on_get_goal(None)
                else:
                    self.on_load_recent_goals()
                # 更新弹窗内容
                instance.text = self.goal_result_edit.text

    def _show_popup(self, title, text):
        """通用提示弹窗"""
        content = Label(
            text=text, font_name='STKaiti', font_size=16,
            color=(139 / 255, 69 / 255, 19 / 255, 1),
            halign='center', valign='middle'
        )
        # 修复Label居中
        content.bind(size=content.setter('text_size'))
        popup = Popup(
            title=title, content=content,
            size_hint=(0.7, 0.4), auto_dismiss=True
        )
        popup.open()