# kivy_ui/function_pages/base_function_page.py
import os
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.label import Label
from kivy.uix.button import Button  # 补全缺失的Button导入
from kivy.graphics import Color, Rectangle
from kivy.core.text import LabelBase
from kivy.properties import StringProperty, BooleanProperty
from kivy.uix.popup import Popup
from kivy.clock import Clock

# 注册字体（和主程序/所有功能页一致）
LabelBase.register(name='STKaiti', fn_regular='stkaiti.ttf')
LabelBase.register(name='SimHei', fn_regular='simhei.ttf')

# 项目根目录 & 功能页统一背景（复用手机端路径，兼容路径计算）
try:
    BASE_DIR = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
    FUNC_BG_PATH = os.path.join(BASE_DIR, "resources", "images", "backgrounds", "func_bg.jpg")
except:
    # 路径计算失败时的兜底方案
    FUNC_BG_PATH = "resources/images/backgrounds/func_bg.jpg"


class BaseFunctionPage(BoxLayout):
    """Kivy版所有功能页公共基类：抽离通用UI+背景+音乐+布局+登录校验"""
    func_name = StringProperty("")  # 功能名称
    username = StringProperty("")   # 用户名
    is_login = BooleanProperty(False)  # 登录状态

    def __init__(self, func_name, username="", is_login=False, **kwargs):
        super().__init__(**kwargs)
        # 公共属性初始化
        self.func_name = func_name
        self.username = username
        self.is_login = is_login
        self.orientation = 'vertical'
        self.padding = 15
        self.spacing = 10

        # 核心：登录校验（创作/打卡/目标必须登录）
        if "创作" in self.func_name or "打卡" in self.func_name or "目标" in self.func_name:
            if not self.is_login or not self.username:
                self.show_login_warning()
                return

        # 初始化公共UI
        self.init_base_ui()
        # 播放功能页统一音乐（后续对接真实音频逻辑）
        self.play_func_music()

    def init_base_ui(self):
        """初始化公共UI：背景+统一标题+基础布局"""
        # 1. 古风背景（兼容兜底）
        self.set_background()
        # 2. 统一功能标题（和电脑端样式对齐）
        self.add_func_title()

    def set_background(self):
        """设置功能页统一背景（古风米黄兜底，修复背景绑定）"""
        with self.canvas.before:
            if os.path.exists(FUNC_BG_PATH):
                # 后续可扩展加载背景图，先沿用诗词页的古风底色
                Color(240 / 255, 230 / 255, 210 / 255, 0.9)
            else:
                Color(250 / 255, 245 / 255, 230 / 255, 1)  # 古风米黄兜底
            self.bg_rect = Rectangle(size=self.size, pos=self.pos)
        # 绑定背景大小/位置到控件，适配窗口缩放
        self.bind(
            size=lambda s, v: setattr(self.bg_rect, 'size', v),
            pos=lambda s, v: setattr(self.bg_rect, 'pos', v)
        )

    def add_func_title(self):
        """添加统一功能标题（修复背景绑定，适配控件缩放）"""
        title_label = Label(
            text=f"📚 {self.func_name}",
            font_name='STKaiti',
            font_size=18,
            color=(139 / 255, 69 / 255, 19 / 255, 1),
            halign='center',
            valign='middle',  # 垂直居中
            size_hint=(1, None),
            height=40
        )
        # 修复：标题背景绑定size/pos，适配缩放
        with title_label.canvas.before:
            Color(250/255, 245/255, 230/255, 0.8)
            self.title_bg = Rectangle(size=title_label.size, pos=title_label.pos)
        title_label.bind(
            size=lambda s, v: setattr(self.title_bg, 'size', v),
            pos=lambda s, v: setattr(self.title_bg, 'pos', v)
        )
        self.add_widget(title_label)

    def play_func_music(self):
        """播放功能页统一音乐（占位逻辑，预留对接接口）"""
        try:
            # 后续替换为真实音频播放逻辑：
            # 1. 停止主界面背景音乐
            # 2. 播放当前功能页专属音乐
            print(f"[音频] 播放{self.func_name}专属背景音乐")
        except Exception as e:
            # 音频播放失败不影响功能页使用
            print(f"[音频] 播放{self.func_name}音乐失败：{str(e)}")

    def show_login_warning(self):
        """登录校验弹窗（统一样式，优化交互）"""
        popup_layout = BoxLayout(orientation='vertical', padding=15, spacing=10)
        popup_layout.add_widget(Label(
            text="请先登录解锁该功能！",
            font_name='STKaiti',
            font_size=16,
            color=(139/255, 69/255, 19/255, 1),
            halign='center',
            size_hint=(1, 0.8)
        ))
        confirm_btn = Button(
            text="确定",
            font_name='SimHei',
            font_size=14,
            size_hint=(None, None),
            size=(80, 30),
            pos_hint={'center_x': 0.5},
            background_color=(139/255, 69/255, 19/255, 0.8),
            color=(1, 1, 1, 1)
        )
        # 创建弹窗（优化弹窗样式）
        popup = Popup(
            title="权限提示",
            content=popup_layout,
            size_hint=(0.7, 0.4),
            auto_dismiss=False,  # 必须点击确定才能关闭
            title_font='STKaiti',
            title_color=(139/255, 69/255, 19/255, 1)
        )
        confirm_btn.bind(on_press=lambda x: popup.dismiss())
        popup_layout.add_widget(confirm_btn)
        popup.open()

    # 预留方法：子类实现专属UI（核心）
    def load_func_ui(self):
        """所有子类必须实现：加载功能专属UI"""
        pass

    # 统一资源清理：停止音乐/动画（解决闪退）
    def stop_resource(self):
        """功能页切换时的资源清理入口（增强异常处理）"""
        try:
            # 1. 停止音乐（后续对接真实音频）
            print(f"[音频] 停止{self.func_name}背景音乐")
            # 2. 停止所有定时器/动画，防止内存泄漏
            Clock.unschedule_all()
            # 3. 清理画布（可选，防止残留）
            self.canvas.before.clear()
        except Exception as e:
            # 资源清理失败不影响程序退出
            print(f"[清理] 停止{self.func_name}资源失败：{str(e)}")