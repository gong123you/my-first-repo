from kivy.uix.screenmanager import Screen
from kivy.uix.label import Label
from kivy.uix.button import Button
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.image import Image
from kivy.graphics import Color, Rectangle
from kivy.core.window import Window
from kivy.properties import ObjectProperty
from kivy.clock import Clock
import os
import sys

# 核心修改：导入kivy_audio（移除pygame）
from kivy_audio import kivy_audio_player

# 适配Kivy的背景路径
BASE_DIR = getattr(sys, '_MEIPASS', os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
COVER_BG_PATH = os.path.join(BASE_DIR, "resources", "images", "backgrounds", "cover_bg.jpg")

class CoverPage(Screen):
    start_signal = ObjectProperty(None)

    def __init__(self, **kwargs):
        # 接收全局音频状态参数（不再依赖pygame）
        self.audio_inited = kwargs.pop('audio_inited', False)
        super().__init__(**kwargs)

        # 纯色保底背景
        with self.canvas.before:
            Color(240 / 255, 230 / 255, 210 / 255, 1)
            self.bg_rect = Rectangle(size=self.size, pos=self.pos)
        self.bind(size=self._update_bg_rect, pos=self._update_bg_rect)

        self.init_ui()
        self.init_layout()

    def _update_bg_rect(self, *args):
        self.bg_rect.size = self.size
        self.bg_rect.pos = self.pos

    def init_ui(self):
        # 标题标签
        self.title_label = Label(
            text="古风文韵",
            font_name='STKaiti',
            font_size=60,
            bold=True,
            color=(92 / 255, 64 / 255, 51 / 255, 1),
            halign='center',
            valign='middle'
        )
        # 标题阴影
        with self.title_label.canvas.after:
            Color(0, 0, 0, 0.3)
            self.shadow = Rectangle(
                texture=self.title_label.texture,
                pos=(self.title_label.x + 2, self.title_label.y - 2),
                size=self.title_label.size
            )
        self.title_label.bind(texture=self._update_shadow, pos=self._update_shadow, size=self._update_shadow)

        # 开始按钮
        self.start_btn = Button(
            text="开启文学之旅",
            font_name='SimHei',
            font_size=32,
            bold=True,
            size_hint=(None, None),
            width=400,
            height=100,
            background_normal='',
            background_color=(139 / 255, 69 / 255, 19 / 255, 0.9),
            border=(20, 20, 20, 20),
            color=(1, 1, 1, 1)
        )
        self.start_btn.bind(on_press=self.on_start_click)

    def _update_shadow(self, *args):
        if hasattr(self, 'shadow'):
            self.shadow.pos = (self.title_label.x + 2, self.title_label.y - 2)
            self.shadow.size = self.title_label.size
            self.shadow.texture = self.title_label.texture

    def init_layout(self):
        # 原生Image显示背景图
        self.add_widget(Image(source=COVER_BG_PATH, allow_stretch=True, keep_ratio=False))
        # 布局
        main_layout = BoxLayout(orientation='vertical', spacing=80, padding=0)
        main_layout.add_widget(Label(size_hint_y=1))
        main_layout.add_widget(self.title_label)
        main_layout.add_widget(self.start_btn)
        main_layout.add_widget(Label(size_hint_y=1))
        self.add_widget(main_layout)

    def on_enter(self):
        """播放封面页音乐（改用kivy_audio）"""
        Clock.schedule_once(lambda dt: kivy_audio_player.play_scene_music("cover"), 0.5)
        self.canvas.ask_update()
        Window.canvas.ask_update()

    def on_start_click(self, *args):
        """停止音乐并跳转（改用kivy_audio）"""
        try:
            kivy_audio_player.stop_bg_music()
            if self.start_signal:
                self.start_signal()
        except Exception as e:
            print(f"点击按钮报错：{e}")

# 测试代码
if __name__ == '__main__':
    from kivy.app import App
    from kivy.core.text import LabelBase
    LabelBase.register(name='STKaiti', fn_regular='stkaiti.ttf')
    LabelBase.register(name='SimHei', fn_regular='simhei.ttf')

    class TestApp(App):
        def build(self):
            Window.size = (1000, 700)
            return CoverPage(audio_inited=False)

    TestApp().run()