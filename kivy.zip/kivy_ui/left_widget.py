from kivy.uix.boxlayout import BoxLayout
from kivy.uix.label import Label
from kivy.uix.button import Button
from kivy.uix.popup import Popup
from kivy.uix.gridlayout import GridLayout
from kivy.graphics import Color, Rectangle
from kivy.core.window import Window
from kivy.properties import ObjectProperty, BooleanProperty
from kivy.clock import Clock
from kivy.animation import Animation
import os
import sys

# 路径配置（适配移动端）
BASE_DIR = getattr(sys, '_MEIPASS', os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
LEFT_BG_PATH = os.path.join(BASE_DIR, "resources", "images", "backgrounds", "left_func_bg.jpg")
BACKUP_COLOR = (139 / 255, 69 / 255, 19 / 255, 1)  # 深棕色兜底


class LeftFunctionWidget(BoxLayout):
    # 核心信号（对应电脑端func_clicked）
    func_clicked = ObjectProperty(None)
    # 登录状态管控（和login_page同步）
    is_login = BooleanProperty(False)
    # 弹出菜单控制
    is_menu_show = BooleanProperty(False)

    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.orientation = "vertical"
        self.size_hint = (None, 1)
        self.width = 0  # 默认隐藏（手机端弹出式）
        self.spacing = 8
        self.padding = [15, 20, 15, 20]

        # 存储按钮实例（用于权限管控）
        self.func_btns_dict = {}
        # 更多赏析弹窗
        self.more_appr_popup = None

        # 初始化UI
        self.init_background()
        self.init_ui()
        self.update_btn_status()  # 初始按游客态锁定

    def init_background(self):
        """设置背景（优先图片，无图用兜底色）"""
        with self.canvas.before:
            if os.path.exists(LEFT_BG_PATH):
                self.bg = Rectangle(source=LEFT_BG_PATH, size=self.size, pos=self.pos)
            else:
                Color(*BACKUP_COLOR)
                self.bg = Rectangle(size=self.size, pos=self.pos)
        self.bind(size=self._update_bg, pos=self._update_bg)

    def _update_bg(self, *args):
        self.bg.size = self.size
        self.bg.pos = self.pos

    def init_ui(self):
        """初始化布局（修复空白区+适配手机端）"""
        # ========== 修复：填充橙棕色空白区 - 加大标题 ==========
        main_title = Label(
            text="古风文韵",
            font_name='STKaiti',
            font_size=28 if Window.width < 800 else 32,
            bold=True,
            color=(1, 0.97, 0.91, 1),
            size_hint_y=None,
            height=60,
            halign='center'
        )
        self.add_widget(main_title)

        # 子标题
        sub_title = Label(
            text="功能菜单",
            font_name='STKaiti',
            font_size=20 if Window.width < 800 else 22,
            bold=True,
            color=(0xD2 / 255, 0xB4 / 255, 0x8C / 255, 1),
            size_hint_y=None,
            height=30,
            halign='center'
        )
        self.add_widget(sub_title)

        # 主分割线
        self.add_widget(self._create_line(height=2, color=(1, 0.97, 0.91, 0.8)))

        # 首页区
        self._add_section_title("🏠 首页")
        self._add_func_btn("主界面", "main_home", enabled=True)
        self.add_widget(self._create_line(height=1, color=(1, 0.97, 0.91, 0.5)))

        # 查询区（游客可用）
        self._add_section_title("🔍 查询区（名字/内容/关键词/图片）")
        self._add_func_btn("诗词专区", "query_poem", enabled=True)
        self._add_func_btn("古文专区", "query_prose", enabled=True)
        self._add_func_btn("词语/成语", "query_word", enabled=True)

        # 赏析区（游客可用+更多弹窗）
        self._add_section_title("赏析区（高考语文·精准考点）")
        self._add_func_btn("人物形象", "appr_character", enabled=True)
        self._add_func_btn("环境描写", "appr_environment", enabled=True)
        self._add_more_appr_btn("更多赏析 ▼", enabled=True)

        # 游客/登录分割线
        split_label = Label(
            text="—— 登录解锁以下功能 ——",
            font_name='STKaiti',
            font_size=12,
            color=(0xE8 / 255, 0xD9 / 255, 0xC3 / 255, 1),
            size_hint_y=None,
            height=30,
            halign='center'
        )
        self.add_widget(split_label)
        self.add_widget(self._create_line(height=1, color=(0xE8 / 255, 0xD9 / 255, 0xC3 / 255, 0.5)))

        # 创作打卡区（登录解锁）
        self._add_section_title("✅ 创作打卡区", is_unlock=True)
        self._add_func_btn("创作（诗词/文章）", "create_work", enabled=False)
        self._add_func_btn("每日打卡", "checkin_daily", enabled=False)
        self._add_func_btn("个人目标定制", "goal_custom", enabled=False)

        # 账号管理区（登录解锁）
        self._add_section_title("账号管理", is_unlock=True)
        self._add_func_btn("重新注册", "account_rereg", enabled=False)
        self._add_func_btn("退出登录", "account_logout", enabled=False)

    def _create_line(self, height=2, color=(1, 0.97, 0.91, 0.8)):
        """创建分割线（修复：单独存储Rectangle对象，避免依赖children索引）"""
        line = Label(size_hint_y=None, height=height)
        # 单独创建并存储Rectangle对象
        with line.canvas.before:
            Color(*color)
            line.line_rect = Rectangle(size=line.size, pos=line.pos)

        # 绑定尺寸和位置更新（直接操作line_rect，不再取children）
        def update_rect_size(instance, value):
            instance.line_rect.size = value

        def update_rect_pos(instance, value):
            instance.line_rect.pos = value

        line.bind(size=update_rect_size, pos=update_rect_pos)
        return line

    def _add_section_title(self, text, is_unlock=False):
        """添加分区标题（适配移动端字体）"""
        font_size = 18 if not is_unlock else 17
        label = Label(
            text=text,
            font_name='STKaiti',
            font_size=font_size,
            bold=True,
            color=(0xD2 / 255, 0xB4 / 255, 0x8C / 255, 1),
            size_hint_y=None,
            height=30
        )
        self.add_widget(label)

    def _add_func_btn(self, text, tag, enabled):
        """添加功能按钮（复刻电脑端样式+权限管控）"""
        btn = Button(
            text=text,
            font_name='SimHei',
            font_size=14,
            size_hint_y=None,
            height=48,
            disabled=not enabled
        )
        # 按钮样式（复刻电脑端启用/禁用状态）
        if enabled:
            btn.background_color = (101 / 255, 67 / 255, 33 / 255, 0.85)
            btn.color = (1, 0.97, 0.91, 1)
        else:
            btn.background_color = (139 / 255, 69 / 255, 19 / 255, 0.4)
            btn.color = (0.96, 0.93, 0.88, 1)

        btn.bind(on_press=lambda x, t=tag: self.on_func_click(t))
        self.func_btns_dict[tag] = btn
        self.add_widget(btn)

    def _add_more_appr_btn(self, text, enabled):
        """添加更多赏析按钮（绑定弹窗）"""
        btn = Button(
            text=text,
            font_name='SimHei',
            font_size=14,
            size_hint_y=None,
            height=48,
            disabled=not enabled
        )
        if enabled:
            btn.background_color = (101 / 255, 67 / 255, 33 / 255, 0.85)
            btn.color = (1, 0.97, 0.91, 1)
        btn.bind(on_press=self.show_more_appr_menu)
        self.func_btns_dict["appr_more"] = btn
        self.add_widget(btn)
        return btn

    def show_more_appr_menu(self, *args):
        """更多赏析弹窗（复刻电脑端6个赏析维度）"""
        # 弹窗布局
        layout = GridLayout(cols=1, spacing=10, padding=20)
        appr_items = [
            ("情感主旨", "appr_theme"),
            ("情节作用", "appr_plot"),
            ("修辞手法", "appr_rhetoric"),
            ("语言风格", "appr_language"),
            ("写作手法", "appr_writing"),
            ("表达技巧", "appr_skill")
        ]
        # 添加弹窗按钮
        for text, tag in appr_items:
            btn = Button(
                text=text,
                font_name='SimHei',
                font_size=14,
                background_color=(101 / 255, 67 / 255, 33 / 255, 0.98),
                color=(1, 0.97, 0.91, 1)
            )
            btn.bind(on_press=lambda x, t=tag: [self.on_func_click(t), self.more_appr_popup.dismiss()])
            layout.add_widget(btn)

        # 创建弹窗（适配移动端尺寸）
        self.more_appr_popup = Popup(
            title="更多赏析维度",
            content=layout,
            size_hint=(0.8, 0.7),
            background_color=(101 / 255, 67 / 255, 33 / 255, 0.98),
            title_font='STKaiti',
            title_color=(1, 0.97, 0.91, 1)
        )
        self.more_appr_popup.open()

    def on_func_click(self, tag):
        """按钮点击统一回调"""
        if self.func_clicked:
            self.func_clicked(tag)

    def update_btn_status(self):
        """更新按钮权限：创作打卡需登录，账号管理始终可用"""
        # 1. 创作打卡区：登录解锁/游客锁定（核心）
        unlock_tags = ["create_work", "checkin_daily", "goal_custom"]
        for tag in unlock_tags:
            if tag in self.func_btns_dict:
                btn = self.func_btns_dict[tag]
                btn.disabled = not self.is_login
                # 更新样式
                if self.is_login:
                    btn.background_color = (101 / 255, 67 / 255, 33 / 255, 0.85)
                    btn.color = (1, 0.97, 0.91, 1)
                else:
                    btn.background_color = (139 / 255, 69 / 255, 19 / 255, 0.4)
                    btn.color = (0.96, 0.93, 0.88, 1)

        # 2. 账号管理区：始终可用（不管是否登录）
        account_tags = ["account_rereg", "account_logout"]
        for tag in account_tags:
            if tag in self.func_btns_dict:
                btn = self.func_btns_dict[tag]
                btn.disabled = False  # 强制解锁
                btn.background_color = (101 / 255, 67 / 255, 33 / 255, 0.85)
                btn.color = (1, 0.97, 0.91, 1)

    def on_is_login(self, *args):
        """登录状态变化时更新按钮"""
        self.update_btn_status()

    # ========== 新增：手机端弹出/隐藏菜单动画 ==========
    def show_menu(self):
        """弹出菜单"""
        target_width = Window.width * 0.35 if Window.width * 0.35 < 260 else 260
        anim = Animation(width=target_width, duration=0.3, t='out_cubic')
        anim.start(self)
        self.is_menu_show = True

    def hide_menu(self):
        """隐藏菜单"""
        anim = Animation(width=0, duration=0.3, t='out_cubic')
        anim.start(self)
        self.is_menu_show = False

    def toggle_menu(self):
        """切换菜单显示/隐藏（纯动画，无任何刷新逻辑）"""
        if self.is_menu_show:
            self.hide_menu()
        else:
            self.show_menu()


# 整合左侧导航栏的主界面容器（手机端弹出式菜单）
class MainWithLeftWidget(BoxLayout):
    # 暴露content_area供外部替换（主界面核心）
    content_area = ObjectProperty(None)
    menu_btn = ObjectProperty(None)
    left_widget = ObjectProperty(None)

    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.orientation = "horizontal"
        self.spacing = 0

        # 左侧弹出式导航栏
        self.left_widget = LeftFunctionWidget()
        self.left_widget.func_clicked = self.on_left_func_click
        self.add_widget(self.left_widget)

        # 右侧内容区（加菜单按钮）
        self.content_layout = BoxLayout(orientation='vertical')
        # 顶部菜单按钮（手机端核心：只做展开/收起，无其他逻辑）
        self.menu_btn = Button(
            text="☰ 菜单",
            font_name='SimHei',
            font_size=18,
            size_hint_y=None,
            height=50,
            background_color=(139 / 255, 69 / 255, 19 / 255, 0.9),
            color=(1, 1, 1, 1)
        )
        # 仅绑定菜单展开/收起，无任何刷新逻辑
        self.menu_btn.bind(on_press=lambda x: self.left_widget.toggle_menu())
        self.content_layout.add_widget(self.menu_btn)

        # 内容显示区（供main_page替换）
        self.content_area = Label(
            text="功能内容区",
            font_name='STKaiti',
            font_size=24,
            color=(0x5C / 255, 0x40 / 255, 0x33 / 255, 1)
        )
        self.content_layout.add_widget(self.content_area)
        self.add_widget(self.content_layout)

    def on_left_func_click(self, tag):
        """左侧按钮点击回调（仅更新文字，无刷新）"""
        # ========== 彻底停止轮播+音频（核心修复） ==========
        # 1. 获取主界面实例
        from kivy.app import App
        main_page = App.get_running_app().root.get_screen('main')  # 主界面screen名按你实际的改

        # 2. 强制清除所有轮播计时器（终极方案）
        Clock.unschedule(main_page.start_img_carousel)  # 清除轮播函数所有计时器
        main_page.carousel_event = None  # 置空计时器引用

        # 3. 停止音频和轮播
        main_page.stop_play()

        # 4. 只有点击功能页按钮（非主界面/非退出登录），才播放功能页音乐
        if tag not in ["main_home", "account_logout"]:
            from kivy_audio import kivy_audio_player
            kivy_audio_player.play_scene_music("func")
        # ===================================================

        self.content_area.text = f"当前功能：{tag}"
        # 退出登录逻辑（仅保留你原本的代码，无任何音乐相关改动）
        if tag == "account_logout":
            self.left_widget.is_login = False
            self.left_widget.hide_menu()
            self.content_area.text = "已退出登录，部分功能已锁定"

    # ========== 新增：接收登录状态 ==========
    def set_login_status(self, is_login, nickname=""):
        """从login_page接收登录状态（仅更新文字，无刷新）"""
        self.left_widget.is_login = is_login
        if is_login:
            self.content_area.text = f"欢迎 {nickname}！点击左侧菜单使用全部功能"
        else:
            self.content_area.text = "当前为游客模式，登录后解锁全部功能"


# 测试代码
if __name__ == '__main__':
    from kivy.app import App
    from kivy.core.text import LabelBase

    LabelBase.register(name='STKaiti', fn_regular='stkaiti.ttf')
    LabelBase.register(name='SimHei', fn_regular='simhei.ttf')


    class TestApp(App):
        def build(self):
            # 测试登录态
            main = MainWithLeftWidget()
            main.set_login_status(True, "测试用户")
            return main


    TestApp().run()