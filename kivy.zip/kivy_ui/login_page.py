from kivy.uix.screenmanager import Screen
from kivy.uix.label import Label
from kivy.uix.button import Button
from kivy.uix.textinput import TextInput
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.image import Image
from kivy.uix.dropdown import DropDown
from kivy.uix.button import Button as DropButton
from kivy.uix.popup import Popup
from kivy.graphics import Color, Rectangle
from kivy.core.window import Window
from kivy.properties import ObjectProperty, BooleanProperty, StringProperty
from kivy.clock import Clock
import os
import sys
import json

# 核心修改：导入kivy_audio（移除pygame）
from kivy_audio import kivy_audio_player

# 适配移动端屏幕方向（优先竖屏）
Window.softinput_mode = 'below_target'  # 软键盘不遮挡输入框

# 路径配置（适配移动端）
BASE_DIR = getattr(sys, '_MEIPASS', os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
LOGIN_BG_PATH = os.path.join(BASE_DIR, "resources", "images", "backgrounds", "login_bg.jpg")
USER_DATA_FILE = os.path.join(BASE_DIR, "resources", "user_data.json")  # 修正：放到resources目录更规范


class LoginPage(Screen):
    # 核心信号（用于给主界面传递登录状态）
    login_success_signal = ObjectProperty(None)
    register_success_signal = ObjectProperty(None)
    back_signal = ObjectProperty(None)
    visitor_enter_signal = ObjectProperty(None)

    def __init__(self, **kwargs):
        # 接收全局音频状态（不再依赖pygame）
        self.audio_inited = kwargs.pop('audio_inited', False)
        super().__init__(**kwargs)

        # 核心状态（标记真实登录状态）
        self.current_page = StringProperty("login")
        self.has_logined = BooleanProperty(False)  # 真实登录状态标记
        self.logined_user = StringProperty("")  # 保存当前登录用户名
        self.is_operating = BooleanProperty(False)
        self.user_data = {}

        # 初始化
        self.load_user_data()
        self.init_ui()
        self.init_layout()
        self.show_login_page()

    def load_user_data(self):
        """加载用户数据（和电脑端逻辑一致）"""
        # 确保目录存在
        if not os.path.exists(os.path.dirname(USER_DATA_FILE)):
            os.makedirs(os.path.dirname(USER_DATA_FILE))
        # 加载数据
        if os.path.exists(USER_DATA_FILE):
            try:
                with open(USER_DATA_FILE, "r", encoding="utf-8") as f:
                    self.user_data = json.load(f)
            except Exception as e:
                self.show_popup("提示", "用户数据文件损坏，将重新创建！")
                self.user_data = {}
        else:
            self.user_data = {}

    def save_user_data(self):
        """保存用户数据（适配移动端路径）"""
        try:
            data_dir = os.path.dirname(USER_DATA_FILE)
            if not os.path.exists(data_dir):
                os.makedirs(data_dir)
            with open(USER_DATA_FILE, "w", encoding="utf-8") as f:
                json.dump(self.user_data, f, ensure_ascii=False, indent=2)
        except Exception as e:
            self.show_popup("错误", f"用户数据保存失败：{str(e)}")

    def show_popup(self, title, content, callback=None):
        """通用弹窗（适配移动端，支持回调）"""
        layout = BoxLayout(orientation='vertical', padding=20, spacing=20)
        # 适配移动端文字大小
        font_size = 16 if Window.width < 800 else 18
        label = Label(text=content, font_name='SimHei', font_size=font_size, halign='center')
        layout.add_widget(label)
        btn = Button(text='确定', size_hint=(1, 0.3), font_name='SimHei', font_size=20)
        layout.add_widget(btn)

        # 移动端弹窗尺寸优化
        popup_size = (0.9, 0.6) if Window.width < 800 else (0.7, 0.5)
        popup = Popup(title=title, content=layout, size_hint=popup_size, auto_dismiss=False)

        # 弹窗关闭后执行回调
        def on_dismiss(instance):
            popup.dismiss()
            if callback:
                callback()

        btn.bind(on_press=on_dismiss)
        popup.open()

    def init_ui(self):
        """初始化UI（深度适配移动端）"""
        # 背景图（自适应屏幕，防止拉伸变形）
        bg = Image(source=LOGIN_BG_PATH if os.path.exists(LOGIN_BG_PATH) else "",
                   allow_stretch=True, keep_ratio=False)
        self.add_widget(bg)

        # 标题（移动端字号优化）
        title_font_size = 32 if Window.width < 800 else 40
        self.title = Label(
            text="古风文韵·登录",
            font_name='STKaiti',
            font_size=title_font_size,
            bold=True,
            color=(1, 1, 1, 1),
            markup=True
        )
        # 标题阴影优化
        self.title.canvas.after.clear()
        with self.title.canvas.after:
            Color(0x5C / 255, 0x40 / 255, 0x33 / 255, 0.8)
            self.title_shadow = Rectangle(
                texture=self.title.texture,
                pos=(self.title.x + 2, self.title.y - 2),
                size=self.title.size
            )
        self.title.bind(texture=self._update_title_shadow, pos=self._update_title_shadow,
                        size=self._update_title_shadow)

        # 已登录提示
        self.logined_tip = Label(
            text="",
            font_name='STKaiti',
            font_size=18 if Window.width < 800 else 20,
            bold=True,
            color=(0xF0 / 255, 0xE6 / 255, 0x8C / 255, 1)
        )
        self.logined_tip.opacity = 0

        # 输入框（移动端尺寸优化）
        input_width = Window.width * 0.85 if Window.width < 800 else 320
        input_height = 45 if Window.width < 800 else 50
        input_font_size = 20 if Window.width < 800 else 22

        self.user_in = TextInput(
            hint_text="用户名",
            font_name='SimHei',
            font_size=input_font_size,
            size_hint=(None, None),
            size=(input_width, input_height),
            background_color=(1, 1, 1, 0.9),
            hint_text_color=(0.5, 0.5, 0.5, 1),
            padding=[10, 10],  # 内边距优化
            multiline=False
        )

        self.pwd_in = TextInput(
            hint_text="密码",
            font_name='SimHei',
            font_size=input_font_size,
            size_hint=(None, None),
            size=(input_width, input_height),
            background_color=(1, 1, 1, 0.9),
            hint_text_color=(0.5, 0.5, 0.5, 1),
            password=True,
            padding=[10, 10],
            multiline=False
        )

        # 忘记密码
        self.forget_pwd = Label(
            text="[u]忘记密码？[/u]",
            font_name='SimHei',
            font_size=14 if Window.width < 800 else 16,
            color=(0x8B / 255, 0x45 / 255, 0x13 / 255, 1),
            markup=True
        )
        self.forget_pwd.bind(on_touch_down=self.show_pwd_tip)

        # 注册相关（移动端尺寸适配）
        self.gender_btn = Button(
            text="性别",
            font_name='SimHei',
            font_size=input_font_size,
            size_hint=(None, None),
            size=(input_width, input_height),
            background_color=(1, 1, 1, 0.9)
        )
        self.gender_dropdown = DropDown()
        for gender in ["", "男", "女"]:
            btn = DropButton(text=gender, font_name='SimHei', font_size=18, size_hint_y=None, height=40)
            btn.bind(on_release=lambda btn: self.gender_dropdown.select(btn.text))
            self.gender_dropdown.add_widget(btn)
        self.gender_btn.bind(on_release=self.gender_dropdown.open)
        self.gender_dropdown.bind(on_select=lambda instance, x: setattr(self.gender_btn, 'text', x))

        self.hint_in = TextInput(
            hint_text="密码提示（可选）",
            font_name='SimHei',
            font_size=input_font_size,
            size_hint=(None, None),
            size=(input_width, input_height),
            background_color=(1, 1, 1, 0.9),
            hint_text_color=(0.5, 0.5, 0.5, 1),
            padding=[10, 10],
            multiline=False
        )

        self.nick_in = TextInput(
            hint_text="自定义称呼（可选）",
            font_name='SimHei',
            font_size=input_font_size,
            size_hint=(None, None),
            size=(input_width, input_height),
            background_color=(1, 1, 1, 0.9),
            hint_text_color=(0.5, 0.5, 0.5, 1),
            padding=[10, 10],
            multiline=False
        )

        # 按钮（移动端尺寸/布局优化）
        btn_width = Window.width * 0.4 if Window.width < 800 else 180
        btn_height = 50 if Window.width < 800 else 60
        btn_font_size = 22 if Window.width < 800 else 24

        self.login_btn = Button(
            text="登录",
            font_name='SimHei',
            font_size=btn_font_size,
            bold=True,
            size_hint=(None, None),
            size=(btn_width, btn_height),
            background_color=(0x8B / 255, 0x45 / 255, 0x13 / 255, 0.95)
        )
        # 改动1：恢复原绑定逻辑，删掉强制跳转
        self.login_btn.bind(on_press=self.login_act)

        self.register_btn = Button(
            text="完成注册",
            font_name='SimHei',
            font_size=btn_font_size,
            bold=True,
            size_hint=(None, None),
            size=(btn_width, btn_height),
            background_color=self.login_btn.background_color
        )
        # 改动2：恢复原绑定逻辑，删掉强制跳转
        self.register_btn.bind(on_press=self.register_act)

        self.switch_btn = Button(
            text="去注册",
            font_name='SimHei',
            font_size=20,
            bold=True,
            size_hint=(None, None),
            size=(btn_width, btn_height),
            background_color=(0x8B / 255, 0x73 / 255, 0x55 / 255, 0.95)
        )
        self.switch_btn.bind(on_press=self.switch_page)

        self.visitor_btn = Button(
            text="游客进入",
            font_name='SimHei',
            font_size=btn_font_size,
            bold=True,
            size_hint=(None, None),
            size=(btn_width, btn_height),
            background_color=(0x7F / 255, 0xB7 / 255, 0x7E / 255, 0.95)
        )
        # 改动3：恢复原绑定逻辑，删掉强制跳转
        self.visitor_btn.bind(on_press=self.visitor_act)

        self.back_btn = Button(
            text="返回封面",
            font_name='SimHei',
            font_size=btn_font_size,
            bold=True,
            size_hint=(None, None),
            size=(btn_width, btn_height),
            background_color=self.login_btn.background_color
        )
        self.back_btn.bind(on_press=self.back_act)

    def _update_title_shadow(self, *args):
        """更新标题阴影"""
        if hasattr(self, 'title_shadow'):
            self.title_shadow.pos = (self.title.x + 2, self.title.y - 2)
            self.title_shadow.size = self.title.size

    def init_layout(self):
        """布局（移动端垂直布局优化）"""
        # 主布局（移动端内边距优化）
        padding = [20, 40, 20, 20] if Window.width < 800 else [30, 50, 30, 30]
        self.main_layout = BoxLayout(orientation='vertical', padding=padding, spacing=15)
        self.main_layout.add_widget(self.title)
        self.main_layout.add_widget(self.logined_tip)

        # 输入布局
        self.main_layout.add_widget(self.user_in)
        self.main_layout.add_widget(self.pwd_in)
        self.main_layout.add_widget(self.forget_pwd)

        # 注册布局（初始隐藏）
        self.register_layout = BoxLayout(orientation='vertical', spacing=15)
        self.register_layout.add_widget(self.gender_btn)
        self.register_layout.add_widget(self.hint_in)
        self.register_layout.add_widget(self.nick_in)
        self.register_layout.opacity = 0

        self.main_layout.add_widget(self.register_layout)

        # 按钮布局（移动端换行优化）
        self.btn_layout = BoxLayout(orientation='vertical' if Window.width < 800 else 'horizontal',
                                    spacing=10, size_hint=(1, None), height=220 if Window.width < 800 else 70)
        self.btn_layout.add_widget(self.login_btn)
        self.btn_layout.add_widget(self.switch_btn)
        self.btn_layout.add_widget(self.visitor_btn)
        self.btn_layout.add_widget(self.back_btn)

        self.main_layout.add_widget(self.btn_layout)
        self.add_widget(self.main_layout)

    def show_login_page(self):
        """显示登录页（和电脑端逻辑一致）"""
        self.current_page = "login"
        self.title.text = "古风文韵·登录"

        # 已登录状态处理
        if self.has_logined and self.logined_user and self.logined_user in self.user_data:
            self.logined_tip.text = f"当前已有登录用户：{self.user_data[self.logined_user]['nick']}"
            self.logined_tip.opacity = 1
            self.user_in.text = self.logined_user
            self.visitor_btn.disabled = True
        else:
            self.logined_tip.opacity = 0
            self.visitor_btn.disabled = False

        # 切换按钮
        self.register_layout.opacity = 0
        self.btn_layout.clear_widgets()
        self.btn_layout.add_widget(self.login_btn)
        self.btn_layout.add_widget(self.switch_btn)
        self.btn_layout.add_widget(self.visitor_btn)
        self.btn_layout.add_widget(self.back_btn)

    def show_register_page(self):
        """显示注册页（和电脑端逻辑一致）"""
        self.current_page = "register"
        self.title.text = "古风文韵·注册"
        self.logined_tip.opacity = 0

        self.register_layout.opacity = 1
        self.switch_btn.text = "去登录"
        self.visitor_btn.disabled = False

        self.btn_layout.clear_widgets()
        self.btn_layout.add_widget(self.register_btn)
        self.btn_layout.add_widget(self.switch_btn)
        self.btn_layout.add_widget(self.visitor_btn)
        self.btn_layout.add_widget(self.back_btn)

    def switch_page(self, *args):
        """切换登录/注册页"""
        if self.current_page == "login":
            self.show_register_page()
        else:
            self.show_login_page()

    def show_pwd_tip(self, *args):
        """忘记密码提示（和电脑端逻辑一致）"""
        username = self.user_in.text.strip()
        if not username:
            self.show_popup("提示", "请先输入用户名！")
            return
        if username in self.user_data and self.user_data.get(username, {}).get("hint"):
            self.show_popup("密码提示", f"你的密码提示：{self.user_data[username]['hint']}")
        else:
            self.show_popup("提示", "未设置密码提示或用户名不存在～")

    def login_act(self, *args):
        """登录操作（真实登录逻辑：校验通过才标记状态+跳转）"""
        # 改动4：暂时注释阻塞判断，避免按钮点不动
        # if self.is_operating:
        #     return
        self.is_operating = True
        self.login_btn.disabled = True

        try:
            username = self.user_in.text.strip()
            pwd = self.pwd_in.text.strip()

            # 基础校验
            if not username:
                self.show_popup("提示", "请输入用户名！")
                self.is_operating = False
                self.login_btn.disabled = False
                return
            if not pwd:
                self.show_popup("提示", "请输入密码！")
                self.is_operating = False
                self.login_btn.disabled = False
                return
            if username not in self.user_data:
                self.show_popup("登录失败", "该用户名未注册，请先注册！")
                self.is_operating = False
                self.login_btn.disabled = False
                return
            if self.user_data[username]["pwd"] != pwd:
                self.show_popup("登录失败", "密码错误，请重新输入！")
                self.is_operating = False
                self.login_btn.disabled = False
                return

            # 改动5：标记真实登录状态（核心！）
            self.has_logined = True
            self.logined_user = username

            # 登录成功弹窗+回调
            user_nick = self.user_data[username].get("nick", username)
            self.show_popup("✅ 登录成功", f"欢迎{user_nick}归来！\n愿与君共品古风文韵～",
                            callback=lambda: self.goto_main())  # 弹窗关闭后跳转
            self.pwd_in.text = ""
            # 发送登录成功信号（给主界面传状态）
            if self.login_success_signal:
                self.login_success_signal(username)

        finally:
            self.login_btn.disabled = False
            self.is_operating = False

    def register_act(self, *args):
        """注册操作（真实注册逻辑：校验通过才保存+标记登录+跳转）"""
        # 改动6：暂时注释阻塞判断
        # if self.is_operating:
        #     return
        self.is_operating = True
        self.register_btn.disabled = True

        try:
            username = self.user_in.text.strip()
            pwd = self.pwd_in.text.strip()
            gender = self.gender_btn.text.strip()
            hint = self.hint_in.text.strip()
            custom_nick = self.nick_in.text.strip()

            # 基础校验
            if not username:
                self.show_popup("注册提示", "请输入用户名！")
                self.is_operating = False
                self.register_btn.disabled = False
                return
            if not pwd:
                self.show_popup("注册提示", "请输入密码！")
                self.is_operating = False
                self.register_btn.disabled = False
                return
            if len(username) < 2 or len(username) > 20:
                self.show_popup("注册提示", "用户名长度需在2-20个字符之间！")
                self.is_operating = False
                self.register_btn.disabled = False
                return
            if len(pwd) < 6 or len(pwd) > 20:
                self.show_popup("注册提示", "密码长度需在6-20个字符之间！")
                self.is_operating = False
                self.register_btn.disabled = False
                return

            # 用户名已存在处理
            if username in self.user_data:
                confirm_layout = BoxLayout(orientation='vertical', padding=20, spacing=20)
                confirm_layout.add_widget(
                    Label(text="该用户名已存在，是否确认重新注册？\n重新注册将覆盖原有用户信息！", font_name='SimHei'))
                btn_layout = BoxLayout(spacing=20)
                yes_btn = Button(text='是', size_hint=(0.5, 1), font_name='SimHei')
                no_btn = Button(text='否', size_hint=(0.5, 1), font_name='SimHei')
                btn_layout.add_widget(yes_btn)
                btn_layout.add_widget(no_btn)
                confirm_layout.add_widget(btn_layout)

                popup = Popup(title="用户名已注册", content=confirm_layout, size_hint=(0.8, 0.5), auto_dismiss=False)
                # 确认后执行注册
                yes_btn.bind(on_press=lambda x: [popup.dismiss(),
                                                 self.do_register(username, pwd, gender, hint, custom_nick)])
                no_btn.bind(on_press=lambda x: [popup.dismiss(),
                                                setattr(self, 'is_operating', False),
                                                setattr(self.register_btn, 'disabled', False)])
                popup.open()
            else:
                self.do_register(username, pwd, gender, hint, custom_nick)
        finally:
            if not (username in self.user_data and self.user_data):
                self.register_btn.disabled = False
                self.is_operating = False

    def do_register(self, username, pwd, gender, hint, custom_nick):
        """执行注册（保存数据+标记登录状态）"""
        # 自动生成昵称
        if not custom_nick:
            if gender == "男":
                custom_nick = f"{username}先生"
            elif gender == "女":
                custom_nick = f"{username}小姐"
            else:
                custom_nick = f"{username}阁下"

        # 保存用户信息
        self.user_data[username] = {
            "pwd": pwd,
            "nick": custom_nick,
            "hint": hint,
            "gender": gender
        }
        self.save_user_data()

        # 改动7：标记真实登录状态
        self.has_logined = True
        self.logined_user = username

        # 注册成功弹窗+跳转
        self.show_popup("✅ 注册成功", f"恭喜{custom_nick}注册成功！\n已自动为你登录～",
                        callback=lambda: self.goto_main())  # 弹窗关闭后跳转
        self.pwd_in.text = ""
        self.gender_btn.text = "性别"
        self.hint_in.text = ""
        self.nick_in.text = ""
        # 发送注册成功信号
        if self.register_success_signal:
            self.register_success_signal(username)

        self.register_btn.disabled = False
        self.is_operating = False

    def visitor_act(self, *args):
        """游客进入：不标记登录状态，仅跳转，功能锁定"""
        # 改动8：暂时注释阻塞判断
        # if self.is_operating:
        #     return
        self.is_operating = True
        self.visitor_btn.disabled = True

        try:
            self.show_popup("✅ 游客进入", "欢迎以游客身份体验～\n部分个性化功能将无法使用",
                            callback=lambda: self.goto_main())  # 弹窗关闭后跳转
            if self.visitor_enter_signal:
                self.visitor_enter_signal()
        finally:
            self.visitor_btn.disabled = False
            self.is_operating = False

    def goto_main(self):
        """统一跳转主界面方法（仅校验通过后调用）"""
        if hasattr(self, 'manager') and self.manager:
            # 给主界面传递登录状态
            self.manager.logined_user = self.logined_user
            self.manager.has_logined = self.has_logined
            self.manager.current = 'main'

    def back_act(self, *args):
        """返回封面（确保信号触发）"""
        if self.back_signal:
            self.back_signal()

    def on_enter(self):
        """页面显示时播放音乐（改用kivy_audio）"""
        kivy_audio_player.play_scene_music("login")

    def on_leave(self):
        """页面离开时停止音乐（改用kivy_audio）"""
        kivy_audio_player.stop_bg_music()


# 测试代码
if __name__ == '__main__':
    from kivy.app import App
    from kivy.core.text import LabelBase
    from kivy.uix.screenmanager import ScreenManager

    # 注册中文字体（确保测试时不显示方块）
    LabelBase.register(name='STKaiti', fn_regular='stkaiti.ttf')
    LabelBase.register(name='SimHei', fn_regular='simhei.ttf')


    # 测试用主界面（模拟）
    class MainScreen(Screen):
        def __init__(self, **kwargs):
            super().__init__(**kwargs)
            self.add_widget(Label(text="主界面", font_name='SimHei', font_size=30))


    class TestApp(App):
        def build(self):
            sm = ScreenManager()
            sm.add_widget(LoginPage(name='login'))
            sm.add_widget(MainScreen(name='main'))
            return sm


    TestApp().run()