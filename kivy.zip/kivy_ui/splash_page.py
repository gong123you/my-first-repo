from kivy.uix.screenmanager import Screen
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.label import Label
from kivy.uix.boxlayout import BoxLayout as BL
from kivy.clock import Clock
from kivy.graphics import Color, Rectangle
from kivy.animation import Animation
from kivy.core.window import Window
from kivy.properties import NumericProperty, ObjectProperty
import os
import sys
import numpy as np
from kivy.core.audio import SoundLoader

# 导入kivy_audio（仅用于封面背景音乐）
from kivy_audio import kivy_audio_player

# 固定绝对路径（避免路径适配问题）
BASE_DIR = "D:/AncientLiteraryApp"


class CharLabel(Label):
    """单个文字标签，封装透明度和位置动画"""
    opacity_val = NumericProperty(0)
    start_y = NumericProperty(0)

    def __init__(self, char, **kwargs):
        super().__init__(**kwargs)
        self.text = char
        self.font_name = 'STKaiti'
        self.font_size = 100
        self.bold = True
        self.color = (1, 1, 1, 1)
        self.halign = 'center'
        self.valign = 'middle'

        self.bind(opacity_val=self.setter('opacity'))

        # 文字阴影
        self.canvas.after.clear()
        with self.canvas.after:
            Color(0, 0, 0, 0.8)
            self.shadow = Rectangle(
                texture=self.texture,
                pos=(self.x + 2, self.y - 2),
                size=self.size
            )
        self.bind(texture=self._update_shadow, pos=self._update_shadow, size=self._update_shadow)

    def _update_shadow(self, *args):
        """更新文字阴影位置和大小"""
        if hasattr(self, 'shadow'):
            self.shadow.pos = (self.x + 2, self.y - 2)
            self.shadow.size = self.size
            self.shadow.texture = self.texture


class SplashPage(Screen, BoxLayout):
    splash_finished = ObjectProperty(None)

    def __init__(self, **kwargs):
        self.audio_inited = kwargs.pop('audio_inited', False)
        super().__init__(**kwargs)

        # 核心参数（首字加缓冲+节奏微调）
        self.app_name = "古风文韵"
        self.char_spacing = 40
        self.total_anim_dur = 3200  # 动画总时长
        self.per_char_delay = 450  # 字间间隔（微调更舒服）
        self.first_char_buffer = 600  # 首字前置缓冲时间（核心！启动后等600ms再出第一个字）
        self.total_dur = 8500  # 闪屏总时长（包含首字缓冲）
        self.float_offset = 30
        self.note_freqs = [440, 494, 523, 587]
        self.note_dur = 0.4  # 音效时长

        # 初始化属性
        self.timer = None
        self.char_labels = []
        self.note_sounds = []  # 存储生成的音效

        # 初始化流程
        if self.audio_inited:
            self._generate_note_sounds()
        self._init_ui()
        self._bind_keyboard()
        self._bind_touch()

        # 启动闪屏（基础延迟保留，叠加首字缓冲）
        Clock.schedule_once(self.start_splash, 0.3)

    def _generate_note_sounds(self):
        """强制生成4个音效，失败则复制补全"""
        try:
            sample_rate = 44100
            temp_dir = os.path.join(BASE_DIR, "temp")
            if not os.path.exists(temp_dir):
                os.makedirs(temp_dir)
            self.note_sounds = []

            for freq in self.note_freqs:
                # 生成正弦波（音量适中，不刺耳）
                t = np.linspace(0, self.note_dur, int(sample_rate * self.note_dur), endpoint=False)
                wave = 0.45 * np.sin(2 * np.pi * freq * t) + 0.12 * np.sin(2 * np.pi * 2 * freq * t)
                # 淡入淡出（平缓不突兀）
                fade_len = max(30, int(0.08 * len(wave)))
                envelope = np.ones_like(wave)
                envelope[:fade_len] = np.linspace(0, 1, fade_len)
                envelope[-fade_len:] = np.linspace(1, 0, fade_len)
                wave = (wave * envelope * 32767).astype(np.int16)

                # 标准WAV头
                data_size = len(wave)
                riff_size = 36 + data_size
                fmt_chunk = b'fmt \x10\x00\x00\x00\x01\x00\x01\x00' + \
                            sample_rate.to_bytes(4, 'little') + \
                            (sample_rate * 2).to_bytes(4, 'little') + \
                            b'\x02\x00\x10\x00'
                data_chunk = b'data' + data_size.to_bytes(4, 'little') + wave.tobytes()
                wav_data = b'RIFF' + riff_size.to_bytes(4, 'little') + b'WAVE' + fmt_chunk + data_chunk

                # 保存+加载+删临时文件
                temp_file = os.path.abspath(os.path.join(temp_dir, f"temp_note_{freq}.wav"))
                with open(temp_file, 'wb') as f:
                    f.write(wav_data)
                sound = SoundLoader.load(temp_file)
                if sound:
                    sound.volume = 0.85
                    self.note_sounds.append(sound)
                    print(f"✅ 生成音效 {freq}Hz 成功")
                else:
                    print(f"⚠️  加载音效{freq}Hz失败，用备用替代")
                    self.note_sounds.append(
                        self.note_sounds[-1] if self.note_sounds else self._generate_backup_sound(temp_dir))
                if os.path.exists(temp_file):
                    os.remove(temp_file)

            # 强制补全4个音效
            while len(self.note_sounds) < 4:
                self.note_sounds.append(
                    self.note_sounds[-1] if self.note_sounds else self._generate_backup_sound(temp_dir))
            print(f"✅ 最终音效数量：{len(self.note_sounds)}（目标4个）")
        except Exception as e:
            print(f"❌ 音效生成异常：{e}")
            self._generate_fallback_sounds()

    def _generate_backup_sound(self, temp_dir):
        """生成基础备用音效"""
        sample_rate = 44100
        t = np.linspace(0, self.note_dur, int(sample_rate * self.note_dur), endpoint=False)
        wave = 0.45 * np.sin(2 * np.pi * 440 * t)
        wave = (wave * 32767).astype(np.int16)
        temp_file = os.path.join(temp_dir, "backup_note.wav")
        with open(temp_file, 'wb') as f:
            f.write(
                b'RIFF$\x00\x00\x00WAVEfmt \x10\x00\x00\x00\x01\x00\x01\x00D\xac\x00\x00\x88X\x01\x00\x02\x00\x10\x00data\x00\x00\x00\x00')
            f.write(wave.tobytes())
        sound = SoundLoader.load(temp_file)
        os.remove(temp_file)
        if sound:
            sound.volume = 0.85
        return sound

    def _generate_fallback_sounds(self):
        """完全失败时兜底：生成4个相同音效"""
        self.note_sounds = []
        temp_dir = os.path.join(BASE_DIR, "temp")
        if not os.path.exists(temp_dir):
            os.makedirs(temp_dir)
        backup = self._generate_backup_sound(temp_dir)
        for _ in range(4):
            self.note_sounds.append(backup)
        print("✅ 启用兜底音效，生成4个基础音效")

    def _play_note_safe(self, idx):
        """音效播放（无额外延迟，和动画同步）"""
        if not self.audio_inited or len(self.note_sounds) == 0:
            return
        play_idx = idx % len(self.note_sounds)
        try:
            sound = self.note_sounds[play_idx]
            if sound.state == 'play':
                sound.stop()
            sound.play()
            print(f"🔊 播放第{idx + 1}个字的音效（{self.note_freqs[play_idx]}Hz）")
        except Exception as e:
            print(f"⚠️  播放音效{idx + 1}失败：{e}")

    def _start_label_anim(self, label, anim_duration, delay):
        """动画启动（速度平缓）"""
        opa_anim = Animation(opacity_val=1, duration=anim_duration / 800, t='in_out_quad')
        pos_anim = Animation(y=label.y - self.float_offset, duration=anim_duration / 800, t='out_cubic')
        combo_anim = opa_anim & pos_anim
        Clock.schedule_once(lambda dt: combo_anim.start(label), delay / 1000)

    def _init_ui(self):
        """UI初始化"""
        with self.canvas.before:
            Color(0, 0, 0, 1)
            self.rect = Rectangle(size=self.size, pos=self.pos)
        self.bind(size=self._update_rect, pos=self._update_rect)

        main_layout = BL(orientation='vertical', spacing=0, padding=0, pos_hint={'center_x': 0.5, 'center_y': 0.5})
        char_layout = BL(orientation='horizontal', spacing=self.char_spacing, padding=0)
        main_layout.add_widget(char_layout)
        self.add_widget(main_layout)

        for char in self.app_name:
            label = CharLabel(char)
            label.opacity_val = 0
            label.start_y = label.y + self.float_offset
            label.y = label.start_y
            char_layout.add_widget(label)
            self.char_labels.append(label)

    def _update_rect(self, *args):
        self.rect.size = self.size
        self.rect.pos = self.pos

    def _bind_keyboard(self):
        """电脑端按键绑定"""
        self._keyboard = Window.request_keyboard(self._keyboard_closed, self)
        if self._keyboard:
            self._keyboard.bind(on_key_down=self._on_key_down)

    def _keyboard_closed(self):
        if hasattr(self, '_keyboard') and self._keyboard:
            self._keyboard.unbind(on_key_down=self._on_key_down)
            self._keyboard = None

    def _on_key_down(self, keyboard, keycode, text, modifiers):
        self._finish_splash()
        return True

    def _bind_touch(self):
        """兼容电脑/手机的触摸绑定"""

        def on_touch_handler(instance, touch):
            if touch.is_touch or (hasattr(touch, 'button') and touch.button == 'left' and touch.is_down):
                self._finish_splash()
                return True

        self.bind(on_touch_down=on_touch_handler)

    def start_splash(self, dt):
        """启动闪屏（核心：首字加前置缓冲，后续字按节奏）"""
        anim_duration = self.total_anim_dur // 4
        for i, label in enumerate(self.char_labels):
            # 计算延迟：首字=前置缓冲，后续字=缓冲+i*字间隔
            total_delay = self.first_char_buffer + (i * self.per_char_delay)

            # 音效+动画用相同延迟，完全同步
            if self.audio_inited:
                Clock.schedule_once(lambda dt, idx=i: self._play_note_safe(idx), total_delay / 1000)
            self._start_label_anim(label, anim_duration, total_delay)

        # 闪屏总时长（包含首字缓冲，足够播放完所有内容）
        self.timer = Clock.schedule_once(self._finish_splash, self.total_dur / 1000)

    def _finish_splash(self, dt=None):
        """闪屏结束处理"""
        if self.timer:
            Clock.unschedule(self.timer)
        if self.audio_inited:
            for sound in self.note_sounds:
                try:
                    sound.stop()
                except:
                    pass
        if self.splash_finished:
            self.splash_finished()
        print("🔚 闪屏结束，跳转主界面")

    def on_enter(self):
        """进入闪屏页播放封面背景音乐"""
        if self.audio_inited:
            kivy_audio_player.play_scene_music("cover")

    def on_leave(self):
        """离开闪屏页停止封面音乐"""
        if self.audio_inited:
            kivy_audio_player.stop_bg_music()

    def on_disable(self):
        """清理资源"""
        if hasattr(self, '_keyboard'):
            self._keyboard.unbind(on_key_down=self._on_key_down)
            self._keyboard = None
        for sound in self.note_sounds:
            try:
                sound.stop()
            except:
                pass
        self.note_sounds = []


# 测试代码
if __name__ == '__main__':
    from kivy.app import App
    from kivy.core.text import LabelBase

    LabelBase.register(name='STKaiti', fn_regular='stkaiti.ttf')
    LabelBase.register(name='SimHei', fn_regular='simhei.ttf')


    class TestApp(App):
        def build(self):
            Window.size = (1000, 700)
            return SplashPage(audio_inited=True)


    TestApp().run()