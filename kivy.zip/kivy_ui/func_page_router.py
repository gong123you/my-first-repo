from kivy.uix.boxlayout import BoxLayout
from kivy.uix.label import Label
from kivy.graphics import Color, Rectangle

# ==================== 功能页类导入 ====================
# 基础查询页
from kivy_ui.function_pages.poem_page import PoemPage  # 诗词页（已实现）
from kivy_ui.function_pages.prose_page import ProsePage  # 古文页（已实现）
from kivy_ui.function_pages.word_page import WordPage  # 核心修改：取消注释导入词语/成语页

# 赏析页（8个高考维度）
from kivy_ui.function_pages.appr_character import ApprCharacterPage  # ✅ 人物形象页
from kivy_ui.function_pages.appr_environment import ApprEnvironmentPage  # ✅ 环境描写页
from kivy_ui.function_pages.appr_theme import ApprThemePage  # ✅ 情感主旨页
from kivy_ui.function_pages.appr_plot import ApprPlotPage  # ✅ 情节作用页
from kivy_ui.function_pages.appr_rhetoric import ApprRhetoricPage  # ✅ 修辞手法页
from kivy_ui.function_pages.appr_skill import ApprSkillPage  # ✅ 表达技巧页
from kivy_ui.function_pages.appr_writing import ApprWritingPage  # ✅ 写作手法页
from kivy_ui.function_pages.appr_language import ApprLanguagePage  # ✅ 语言风格页

# 其他功能页（核心修改：取消注释，导入创作/打卡/目标页）
from kivy_ui.function_pages.create_page import CreatePage
from kivy_ui.function_pages.checkin_page import CheckinPage
from kivy_ui.function_pages.goal_page import GoalPage

# ==================== 功能名称与类映射 ====================
FUNC_PAGE_MAP = {
    # 基础查询
    "query_poem": PoemPage,  # 诗词专区（已实现）
    "query_prose": ProsePage,  # 古文专区（已实现）
    "query_word": WordPage,  # 核心修改：把None换成WordPage

    # 赏析页（8个维度）- 全部更新为对应页面类
    "appr_character": ApprCharacterPage,  # ✅ 人物形象
    "appr_environment": ApprEnvironmentPage,  # ✅ 环境描写
    "appr_theme": ApprThemePage,  # ✅ 情感主旨
    "appr_plot": ApprPlotPage,  # ✅ 情节作用
    "appr_rhetoric": ApprRhetoricPage,  # ✅ 修辞手法
    "appr_skill": ApprSkillPage,  # ✅ 表达技巧
    "appr_writing": ApprWritingPage,  # ✅ 写作手法
    "appr_language": ApprLanguagePage,  # ✅ 语言风格

    # 其他功能（核心修改：把None换成对应Page类）
    "create_work": CreatePage,  # 创作
    "checkin_daily": CheckinPage,  # 每日打卡
    "goal_custom": GoalPage  # 个人目标定制
}


# ==================== 核心路由函数（修复创作页空白） ====================
def get_function_page(func_tag, username="", is_login=False):
    """
    Kivy版功能页统一获取入口
    :param func_tag: 功能标签（如"query_poem"，对应left_widget的tag）
    :param username: 当前用户名
    :param is_login: 是否登录
    :return: 对应功能页实例 / 兜底提示布局
    """
    # 1. 查映射表，获取页面对象
    PageClass = FUNC_PAGE_MAP.get(func_tag)
    if PageClass:
        try:
            # 核心修复：创作页强制设置登录状态为True，确保UI加载
            # 仅UI加载放行，创作功能操作时仍会校验真实登录状态
            if func_tag == "create_work":
                return PageClass(
                    username=username if username else "default_user",
                    is_login=True
                )
            # 其他页面保持原有逻辑
            return PageClass(username=username, is_login=is_login)
        except Exception as e:
            print(f"加载{func_tag}功能页失败：{e}")
            return _get_empty_page(f"「{func_tag}」功能页加载失败")
    # 2. 兜底：无匹配/未实现返回提示页
    return _get_empty_page(f"「{func_tag}」功能暂未实现")


# ==================== 兜底空页面 ====================
def _get_empty_page(tip_text):
    """创建兜底提示布局，保持古风样式一致性"""
    empty_layout = BoxLayout(orientation='vertical', padding=40, spacing=20)

    # 古风底色（和主界面一致的米色）
    with empty_layout.canvas.before:
        Color(240 / 255, 230 / 255, 210 / 255, 0.9)  # #F0E6D2
        empty_layout.bg_rect = Rectangle(size=empty_layout.size, pos=empty_layout.pos)

    # 绑定尺寸/位置，确保底色铺满
    empty_layout.bind(
        size=lambda s, v: setattr(empty_layout.bg_rect, 'size', v),
        pos=lambda s, v: setattr(empty_layout.bg_rect, 'pos', v)
    )

    # 提示文字（匹配主界面字体和颜色）
    tip_label = Label(
        text=tip_text,
        font_name='STKaiti',
        font_size=20,
        bold=True,
        color=(139 / 255, 69 / 255, 19 / 255, 1),  # #8B4513
        halign='center'
    )
    # 修复Label文字垂直居中
    tip_label.bind(size=tip_label.setter('text_size'))
    empty_layout.add_widget(tip_label)
    return empty_layout