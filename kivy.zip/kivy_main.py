import kivy
import os
import sys
from kivy.app import App
from kivy.uix.screenmanager import ScreenManager, Screen, FadeTransition
from kivy.core.text import LabelBase
from kivy.core.window import Window
from kivy.clock import Clock
from kivy.uix.popup import Popup
from kivy.uix.label import Label
from kivy.uix.button import Button
from kivy.uix.boxlayout import BoxLayout
from kivy.properties import StringProperty, BooleanProperty

# ---------------------- 全局初始化（核心：只执行一次） ----------------------
# 1. 移动端窗口适配
Window.fullscreen = False
Window.allow_screensaver = False
Window.softinput_mode = 'below_target'
Window.minimum_width = 320
Window.minimum_height = 480
Window.size = (480, 800) if kivy.platform == 'android' else (1000, 700)

# 2. 音频初始化（替换pygame为kivy_audio）
from kivy_audio import kivy_audio_player
AUDIO_INITED = True  # kivy_audio已内置兼容逻辑

# 3. 注册中文字体
LabelBase.register(name='SimHei', fn_regular='simhei.ttf')
LabelBase.register(name='STKaiti', fn_regular='stkaiti.ttf')

# 4. 资源路径
BASE_DIR = getattr(sys, '_MEIPASS', os.path.dirname(os.path.abspath(__file__)))

# ---------------------- 页面导入 ----------------------
from kivy_ui.splash_page import SplashPage
from kivy_ui.cover_page import CoverPage
from kivy_ui.login_page import LoginPage
# 新增：导入MainPage（核心修改1）
from kivy_ui.main_page import MainPage
# 新增：导入路由函数（第三阶段核心）
from kivy_ui.func_page_router import get_function_page

try:
    from kivy_ui.left_widget import MainWithLeftWidget

    MAIN_UI_LOADED = True
except ImportError as e:
    print(f"主界面导入警告：{e}")
    MAIN_UI_LOADED = False


# ---------------------- 核心App类 ----------------------
class AncientLiteraryApp(App):
    def build(self):
        self.title = "古风文韵 - 高考语文学习助手"
        self.has_logined = False
        self.logined_user = ""
        self.user_nickname = ""

        # 初始化ScreenManager（唯一核心控制器）
        self.sm = ScreenManager(transition=FadeTransition(duration=0.3))

        # 添加闪屏页
        self.splash_page = SplashPage(name='splash', audio_inited=AUDIO_INITED)
        self.splash_page.splash_finished = self.switch_to_cover
        self.sm.add_widget(self.splash_page)

        # 添加封面页
        self.cover_page = CoverPage(name='cover', audio_inited=AUDIO_INITED)
        self.cover_page.start_signal = self.switch_to_login
        self.sm.add_widget(self.cover_page)

        # 添加登录页 + 绑定信号（100%触发）
        self.login_page = LoginPage(name='login', audio_inited=AUDIO_INITED)
        self.login_page.login_success_signal = self.on_login_success
        self.login_page.register_success_signal = self.on_register_success
        self.login_page.back_signal = self.switch_to_cover
        self.login_page.visitor_enter_signal = self.on_visitor_enter
        self.sm.add_widget(self.login_page)

        # 添加主界面（核心修改2：传递audio_inited参数）
        try:
            # 关键修复：给MainPage传入全局音频状态AUDIO_INITED
            self.main_page = MainPage(name='main', audio_inited=AUDIO_INITED)
            # 绑定登录跳转信号
            self.main_page.to_login_signal = self.switch_to_login
            self.sm.add_widget(self.main_page)
            # 绑定左侧导航回调（兼容原有逻辑 + 新增路由）
            if hasattr(self.main_page, 'main_with_left') and hasattr(self.main_page.main_with_left, 'left_widget'):
                self.main_page.main_with_left.left_widget.func_clicked = self.on_left_func_click
        except Exception as e:
            print(f"主界面初始化警告：{e}")
            # 兜底布局：确保主界面始终可访问
            self.main_screen = Screen(name='main')
            fallback_layout = BoxLayout(orientation='vertical', padding=20)
            fallback_layout.add_widget(Label(text="古风文韵·主界面", font_name='STKaiti', font_size=30))
            fallback_layout.add_widget(Label(text="核心功能加载中...", font_name='SimHei', font_size=20))
            back_btn = Button(text="返回登录页", font_name='SimHei', size_hint=(1, 0.2),
                              on_press=lambda x: self.switch_to_login())
            fallback_layout.add_widget(back_btn)
            self.main_screen.add_widget(fallback_layout)
            self.sm.add_widget(self.main_screen)

        # 启动默认显示闪屏页
        self.sm.current = 'splash'
        return self.sm

    # ---------------------- 核心跳转函数（极简+容错） ----------------------
    def switch_to_cover(self, *args):
        """跳封面页"""
        self.sm.current = 'cover'
        # 封面页音乐
        kivy_audio_player.play_scene_music("cover")

    def switch_to_login(self, *args):
        """跳登录页（新增容错：避免登录页未初始化的极小概率问题）"""
        if hasattr(self, 'login_page'):
            self.login_page.has_logined = self.has_logined
            self.login_page.logined_user = self.logined_user
        self.sm.current = 'login'
        # 停止音乐
        kivy_audio_player.stop_bg_music()

    def switch_to_main(self, *args):
        """强制跳主界面（加日志+强制刷新）"""
        print(f"开始跳转主界面：当前ScreenManager的页面是 {self.sm.current}")  # 加日志
        self.sm.current = 'main'
        self.sm.transition = FadeTransition(duration=0.1)  # 强制刷新过渡动画
        print(f"跳转后ScreenManager的页面是 {self.sm.current}")  # 加日志
        # 同步登录状态到MainPage（核心修改3）
        if hasattr(self, 'main_page'):
            self.main_page.is_login = self.has_logined
            self.main_page.nickname = self.user_nickname
            # 播放主界面音乐
            kivy_audio_player.play_scene_music("main")

            # ========== 强化修复：确保清空功能页+重新渲染 ==========
            if hasattr(self.main_page, 'main_with_left'):
                content_layout = self.main_page.main_with_left.content_layout
                # 强制清空所有内容
                content_layout.clear_widgets()
                # 只保留菜单按钮，重新渲染主界面
                content_layout.add_widget(self.main_page.main_with_left.menu_btn)
                # 强制触发渲染（加延时确保生效）
                Clock.schedule_once(lambda dt: self.main_page.render_page(), 0.1)

    # ---------------------- 登录/注册/游客回调（直接跳转） ----------------------
    def on_login_success(self, username):
        """登录成功：无弹窗/延时，直接跳转"""
        self.has_logined = True
        self.logined_user = username
        self.user_nickname = username
        self.switch_to_main()

    def on_register_success(self, username):
        """注册成功：无弹窗/延时，直接跳转"""
        self.has_logined = True
        self.logined_user = username
        self.user_nickname = username
        self.switch_to_main()

    def on_visitor_enter(self, *args):
        """游客进入：强制跳转+延时确认"""
        self.has_logined = False
        self.logined_user = ""
        self.user_nickname = "游客"
        # 延时0.1秒执行，避开Kivy的UI刷新周期
        Clock.schedule_once(lambda dt: self.switch_to_main(), 0.1)

    def on_left_func_click(self, tag):
        """左侧导航回调（加容错+修复参数报错 + 新增路由逻辑）"""
        try:
            if tag == "account_logout":
                # 退出登录：重置状态+跳封面页
                self.has_logined = False
                self.logined_user = ""
                self.user_nickname = ""
                if hasattr(self, 'main_page'):
                    self.main_page.is_login = False
                # 停止音乐
                kivy_audio_player.stop_bg_music()
                self.switch_to_cover()
            elif tag == "main_home":
                # ========== 核心修改：登录态/游客态逻辑统一 ==========
                # 无论是否登录，只要在功能页（内容区有功能页控件），就强制切回主界面
                if hasattr(self, 'main_page') and hasattr(self.main_page, 'main_with_left'):
                    content_layout = self.main_page.main_with_left.content_layout
                    # 判断是否在功能页：内容区除了菜单按钮还有其他控件
                    is_in_func_page = len(content_layout.children) > 1
                    if is_in_func_page:
                        self.switch_to_main()
                    else:
                        # 已在主界面：登录态刷新图片/音乐，游客态无操作
                        if self.main_page.is_login:
                            self.main_page.start_img_carousel(force_switch=True)
                            kivy_audio_player.switch_next_music(AUDIO_INITED)
            elif tag == "account_rereg":
                # 重新注册：跳登录页并切换到注册页（加容错）
                self.switch_to_login()
                Clock.schedule_once(
                    lambda dt: self.login_page.switch_page() if hasattr(self, 'login_page') and hasattr(self.login_page,
                                                                                                        'switch_page') else None,
                    0.5
                )
            else:
                # 新增：其他功能标签走路由（第三阶段核心）
                if hasattr(self, 'main_page') and hasattr(self.main_page, 'main_with_left'):
                    # 1. 清空主界面内容区（保留菜单按钮）
                    content_layout = self.main_page.main_with_left.content_layout
                    content_layout.clear_widgets()
                    content_layout.add_widget(self.main_page.main_with_left.menu_btn)

                    # 2. 调用路由函数获取功能页
                    func_page = get_function_page(
                        func_tag=tag,
                        username=self.logined_user,
                        is_login=self.has_logined
                    )

                    # 3. 添加功能页到内容区
                    content_layout.add_widget(func_page)

                    # 4. 隐藏左侧菜单（提升体验）
                    self.main_page.main_with_left.left_widget.hide_menu()

                    # ========== 新增2：功能页音乐逻辑 ==========
                    # 播放功能页音乐
                    kivy_audio_player.play_scene_music("func")

        except Exception as e:
            print(f"左侧导航回调报错：{e}")


# ---------------------- 程序入口 ----------------------
if __name__ == '__main__':
    AncientLiteraryApp().run()