import jieba
import random
import json
import os
import sys
from datetime import datetime

# 适配手机端路径（指向共用的项目根目录）
BASE_DIR = "D:/AncientLiteraryApp"
DATA_PATH = os.path.join(BASE_DIR, "resources", "data")
os.makedirs(DATA_PATH, exist_ok=True)

# 复用电脑端的赏析维度定义
APPRECIATION_DIMENSIONS = [
    "人物形象", "环境描写", "情节作用", "修辞手法",
    "情感主旨", "语言风格", "写作手法", "表达技巧"
]

# 路径配置（和电脑端完全一致）
APPRECIATION_BASE_PATH = os.path.join(DATA_PATH, "gaokao_appr_")
CREATE_TEMPLATES_PATH = os.path.join(DATA_PATH, "create_templates.json")
ENCOURAGEMENT_PATH = os.path.join(DATA_PATH, "encouragement_words.json")

# 加载励志语库（和电脑端一致）
ENCOURAGEMENT_WORDS = []
if os.path.exists(ENCOURAGEMENT_PATH):
    with open(ENCOURAGEMENT_PATH, "r", encoding="utf-8") as f:
        ENCOURAGEMENT_WORDS = json.load(f) or []


class KivyTextProcessor:
    """手机端文本处理类，优化缓存提升流畅度"""

    def __init__(self):
        # 数据源路径
        self.gaokao_poems_path = os.path.join(DATA_PATH, "gaokao_poems.json")
        self.gaokao_proses_path = os.path.join(DATA_PATH, "gaokao_proses.json")
        self.gaokao_words_path = os.path.join(DATA_PATH, "gaokao_idioms_words.json")

        # 核心优化：初始化时一次性加载所有数据并缓存（只读一次）
        self.poems_data = self._load_json(self.gaokao_poems_path, default=[])
        self.proses_data = self._load_json(self.gaokao_proses_path, default=[])
        self.words_data = self._load_json(self.gaokao_words_path, default=[])

        # 其他路径+缓存（按需）
        self.user_goals_path = os.path.join(DATA_PATH, "user_goals.json")
        self.checkin_records_path = os.path.join(DATA_PATH, "checkin_records.json")
        self.user_data_path = os.path.join(DATA_PATH, "user_data.json")
        self.create_records_path = os.path.join(DATA_PATH, "create_records.json")
        self.appr_lib_cache = {}

    def _load_json(self, file_path, default=None):
        """复刻电脑端 _load_json 方法"""
        if default is None:
            default = {}
        try:
            with open(file_path, "r", encoding="utf-8") as f:
                return json.load(f)
        except (FileNotFoundError, json.JSONDecodeError):
            return default

    def _save_json(self, file_path, data):
        """复刻电脑端 _save_json 方法"""
        with open(file_path, "w", encoding="utf-8") as f:
            json.dump(data, f, ensure_ascii=False, indent=2)

    def query_content(self, query_type, keyword, content_type="poem"):
        """核心查询方法：用缓存数据，不再重复读文件"""
        keyword = keyword.replace('　', ' ').strip()
        if not keyword and query_type not in ["image", "all"]:
            return "🔍 请输入有效查询关键词～"

        # 直接用缓存数据（核心优化点）
        if content_type == "prose":
            data = self.proses_data
            data_name = "古文"
        elif content_type == "word":
            data = self.words_data
            data_name = "成语/词语"
        else:
            data = self.poems_data
            data_name = "诗词"

        # 图片查询（占位，和电脑端一致）
        if query_type == "image":
            return f"根据图片意境匹配{data_name}：{keyword[:10]}...（可扩展图片意境解析功能）"

        # 查询全部
        elif query_type == "all":
            match_items = []
            for item in data:
                if content_type == "poem":
                    match_items.append(
                        f"📜 {item.get('title', '未知标题')}\n"
                        f"{item.get('dynasty', '未知朝代')}·{item.get('author', '未知作者')}\n"
                        f"【文体】：{item.get('category', '未知类别')}\n\n"
                        f"正文：{item.get('content', '暂无内容')}\n\n"
                        f"【考察频率】：{item.get('exam_freq', '高频')}\n\n"
                        f"📝 译文：{item.get('translation', '暂无译文')}"
                    )
                elif content_type == "prose":
                    anno_content = item.get('annotation', '暂无字词注释').replace('<br>', '\n')
                    match_items.append(
                        f"📜 {item.get('title', '未知标题')}\n"
                        f"{item.get('dynasty', '未知朝代')}·{item.get('author', '未知作者')}\n"
                        f"【文体/考情】：{item.get('category', '未知类别')}\n\n"
                        f"原文：{item.get('content', '暂无内容')}\n\n"
                        f"【考察频率】：{item.get('exam_freq', '高频')}\n\n"
                        f"📝 古文译文：\n{item.get('translation', '暂无译文')}\n\n"
                        f"📚 字词注释：\n{anno_content}"
                    )
                else:
                    extend_content = item.get('extend', '暂无拓展信息').replace('<br>', '\n')
                    annotation_content = item.get('annotation', '暂无注释说明').replace('<br>', '\n')
                    match_items.append(
                        f"📜 {item.get('title', '未知成语/词语')}\n"
                        f"【类型】：{item.get('type', '未知类型')}\n\n"
                        f"【核心解析】：{item.get('content', '暂无解析内容')}\n\n"
                        f"📚 【拓展知识】：\n{extend_content}\n\n"
                        f"📝 【注释点睛】：\n{annotation_content}\n\n"
                        f"💡 【经典例句】：{item.get('example', '暂无例句')}\n\n"
                        f"【考察频率】：{item.get('exam_freq', '高频')}"
                    )
            if match_items:
                separator = "\n\n📜 ────────────── 📜\n\n"
                return f"📚 共查询到 {len(match_items)} 条{data_name}全部内容：\n\n" + separator.join(match_items)
            else:
                return f"📭 暂无{data_name}相关数据～"

        # 按名称查询
        elif query_type == "name":
            for item in data:
                item_title = item.get("title", "").replace('　', ' ').strip()
                if item_title == keyword:
                    if content_type == "poem":
                        return (
                            f"📜 {item.get('title', '未知标题')}\n"
                            f"{item.get('dynasty', '未知朝代')}·{item.get('author', '未知作者')}\n"
                            f"【文体】：{item.get('category', '未知类别')}\n\n"
                            f"{item.get('content', '暂无内容')}\n\n"
                            f"【考察频率】：{item.get('exam_freq', '高频')}\n\n"
                            f"📝 诗词译文：\n{item.get('translation', '暂无译文')}"
                        )
                    elif content_type == "prose":
                        anno_content = item.get('annotation', '暂无字词注释').replace('<br>', '\n')
                        return (
                            f"📜 {item.get('title', '未知标题')}\n"
                            f"{item.get('dynasty', '未知朝代')}·{item.get('author', '未知作者')}\n"
                            f"【文体/考情】：{item.get('category', '未知类别')}\n\n"
                            f"原文：{item.get('content', '暂无内容')}\n\n"
                            f"【考察频率】：{item.get('exam_freq', '高频')}\n\n"
                            f"📝 古文译文：\n{item.get('translation', '暂无译文')}\n\n"
                            f"📚 字词注释：\n{anno_content}"
                        )
                    else:
                        extend_content = item.get('extend', '暂无拓展信息').replace('<br>', '\n')
                        annotation_content = item.get('annotation', '暂无注释说明').replace('<br>', '\n')
                        return (
                            f"📜 {item.get('title', '未知成语/词语')}\n"
                            f"【类型】：{item.get('type', '未知类型')}\n\n"
                            f"【核心解析】：{item.get('content', '暂无解析内容')}\n\n"
                            f"📚 【拓展知识】：\n{extend_content}\n\n"
                            f"📝 【注释点睛】：\n{annotation_content}\n\n"
                            f"💡 【经典例句】：{item.get('example', '暂无例句')}\n\n"
                            f"【考察频率】：{item.get('exam_freq', '高频')}"
                        )
            return f"🔍 未查询到《{keyword}》相关高考必备{data_name}：可检查名称是否正确～"

        # 按关键词查询
        else:
            match_items = []
            for item in data:
                if content_type == "poem":
                    item_info = f"{item.get('title', '')} {item.get('author', '')} {item.get('dynasty', '')} {item.get('content', '')} {item.get('category', '')} {item.get('translation', '')}".lower()
                elif content_type == "prose":
                    item_info = f"{item.get('title', '')} {item.get('author', '')} {item.get('dynasty', '')} {item.get('content', '')} {item.get('translation', '')} {item.get('category', '')} {item.get('annotation', '')}".lower()
                else:
                    item_info = f"{item.get('title', '')} {item.get('type', '')} {item.get('content', '')} {item.get('extend', '')} {item.get('annotation', '')} {item.get('example', '')}".lower()

                if keyword.lower() in item_info:
                    if content_type == "poem":
                        match_items.append(
                            f"📜 {item.get('title', '未知标题')}\n"
                            f"{item.get('dynasty', '未知朝代')}·{item.get('author', '未知作者')}\n"
                            f"【文体】：{item.get('category', '未知类别')}\n\n"
                            f"正文：{item.get('content', '暂无内容')}\n\n"
                            f"【考察频率】：{item.get('exam_freq', '高频')}\n\n"
                            f"📝 译文：{item.get('translation', '暂无译文')}"
                        )
                    elif content_type == "prose":
                        anno_content = item.get('annotation', '暂无字词注释').replace('<br>', '\n')
                        match_items.append(
                            f"📜 {item.get('title', '未知标题')}\n"
                            f"{item.get('dynasty', '未知朝代')}·{item.get('author', '未知作者')}\n"
                            f"【文体/考情】：{item.get('category', '未知类别')}\n\n"
                            f"原文：{item.get('content', '暂无内容')}\n\n"
                            f"【考察频率】：{item.get('exam_freq', '高频')}\n\n"
                            f"📝 古文译文：\n{item.get('translation', '暂无译文')}\n\n"
                            f"📚 字词注释：\n{anno_content}"
                        )
                    else:
                        extend_content = item.get('extend', '暂无拓展信息').replace('<br>', '\n')
                        annotation_content = item.get('annotation', '暂无注释说明').replace('<br>', '\n')
                        match_items.append(
                            f"📜 {item.get('title', '未知成语/词语')}\n"
                            f"【类型】：{item.get('type', '未知类型')}\n\n"
                            f"【核心解析】：{item.get('content', '暂无解析内容')}\n\n"
                            f"📚 【拓展知识】：\n{extend_content}\n\n"
                            f"📝 【注释点睛】：\n{annotation_content}\n\n"
                            f"💡 【经典例句】：{item.get('example', '暂无例句')}\n\n"
                            f"【考察频率】：{item.get('exam_freq', '高频')}"
                        )
            if match_items:
                separator = "\n\n📜 ────────────── 📜\n\n"
                return f"🔍 关键词「{keyword}」匹配到{len(match_items)}条高考必备{data_name}：\n\n" + separator.join(
                    match_items)
            else:
                return f"🔍 未查询到包含「{keyword}」的高考必备{data_name}～"

    # ==================== 创作生成方法（和电脑端100%对齐） ====================
    def create_content(self, input_type, generate_type, detail_type, keyword):
        """
        完全对齐电脑端的创作生成方法：加载模板生成内容
        :param input_type: 输入类型（关键词/图片描述）
        :param generate_type: 生成大类（诗词/短文）
        :param detail_type: 细分体裁（五言绝句/古风随笔等）
        :param keyword: 用户输入的关键词
        :return: 适配手机端的纯文本创作内容
        """
        # 1. 加载创作模板文件（对接create_templates.json）
        templates = self._load_json(CREATE_TEMPLATES_PATH, {})
        if not templates:
            return f"{keyword}有感\n浮生偷得半日闲，一笺清韵落眉间。"

        # 2. 拼接模板匹配key（和电脑端逻辑完全一致）
        template_key = f"{input_type}-{detail_type}"
        if template_key not in templates:
            return f"{keyword}有感\n浮生偷得半日闲，一笺清韵落眉间。"

        # 3. 随机选择模板并替换占位符（兼容{keyword}/{scene}/{{关键词}}三种占位符）
        template_list = templates[template_key]
        selected_template = random.choice(template_list)
        # 同时替换电脑端的{keyword}/{scene}和手机端的{{关键词}}，确保全兼容
        result = selected_template.replace("{keyword}", keyword) \
            .replace("{scene}", keyword) \
            .replace("{{关键词}}", keyword)

        # 适配手机端：将HTML换行转为纯文本换行，清理残留HTML标签
        result = result.replace("<br>", "\n").replace("<br/>", "\n").replace("<br />", "\n")

        return result

    # ==================== 赏析通用底层方法 ====================
    def _load_appreciation_lib(self, appr_type):
        """加载赏析词库（对齐电脑端逻辑，强制清理缓存）"""
        if appr_type in self.appr_lib_cache:
            del self.appr_lib_cache[appr_type]
        lib_path = f"{APPRECIATION_BASE_PATH}{appr_type}.json"
        lib_data = self._load_json(lib_path, {})
        if lib_data:
            self.appr_lib_cache[appr_type] = lib_data
        return lib_data

    def _match_keywords(self, text, keyword_lib, match_rule):
        """关键词匹配核心方法（对齐电脑端，强制转小写）"""
        text_lower = text.lower()
        match_result = {}
        min_key = match_rule.get("min_keyword_num", 1)
        max_match = match_rule.get("max_match_num", 3)

        for dim, key_map in keyword_lib.items():
            dim_matches = []
            for label, keywords in key_map.items():
                match_count = sum(1 for kw in keywords if kw and kw.lower() in text_lower)
                if match_count >= min_key:
                    dim_matches.append(label)
            match_result[dim] = dim_matches[:max_match] if dim_matches else ["未明确体现"]
        return match_result

    def _extract_original_basis(self, text, extract_len=None):
        """提取原文依据（对齐电脑端，适配手机端文本展示）"""
        if not text:
            return "无原文内容"
        clean_text = text.replace('\n', '').replace('　', ' ').strip()
        extract_len = extract_len if extract_len is not None else 30
        return clean_text[:extract_len] + "..." if len(clean_text) > extract_len else clean_text

    # ==================== 8大赏析维度核心方法 ====================
    def appreciate_character(self, text):
        """人物形象赏析"""
        try:
            appr_lib = self._load_appreciation_lib("character")
            if not appr_lib:
                return "⚠️ 人物形象赏析词库未加载，请检查gaokao_appr_character.json文件！"

            keyword_lib = appr_lib.get("keyword_lib", {})
            templates = appr_lib.get("appreciation_template", {})
            match_rule = appr_lib.get("match_rule", {})
            if not all([keyword_lib, templates]):
                return "⚠️ 人物形象赏析词库配置不完整！"

            match_res = self._match_keywords(text, keyword_lib, match_rule)
            original_basis = self._extract_original_basis(text, match_rule.get("extract_sentence_len", 20))
            identity = " / ".join(match_res.get("身份定位", ["未明确体现"]))
            character = " / ".join(match_res.get("性格特征", ["未明确体现"]))

            detail_tpl = templates.get("detail", templates.get("base", "赏析模板缺失"))
            appreciation_result = detail_tpl.replace("【身份定位】", identity) \
                .replace("【性格特征】", character) \
                .replace("【原文依据】", original_basis)

            # 适配手机端：移除HTML标签，纯文本展示
            appreciation_result = appreciation_result \
                .replace("<h3 style='color:#5C4033; margin:8px 0;'>", "") \
                .replace("<b>", "") \
                .replace("</b>", "") \
                .replace("</h3>", "") \
                .replace('<br>', '\n') \
                .replace("## ", "") \
                .replace("### ", "") \
                .replace("#", "")
            return appreciation_result
        except Exception as e:
            return f"⚠️ 人物形象赏析出错：{str(e)}"

    def appreciate_environment(self, text):
        """环境描写赏析"""
        try:
            appr_lib = self._load_appreciation_lib("environment")
            if not appr_lib:
                return "⚠️ 环境描写赏析词库未加载，请检查gaokao_appr_environment.json文件！"

            keyword_lib = appr_lib.get("keyword_lib", {})
            templates = appr_lib.get("appreciation_template", {})
            match_rule = appr_lib.get("match_rule", {})
            if not all([keyword_lib, templates]):
                return "⚠️ 环境描写赏析词库配置不完整！"

            match_res = self._match_keywords(text, keyword_lib, match_rule)
            original_basis = self._extract_original_basis(text, match_rule.get("extract_sentence_len", 50))
            env_type = " / ".join(match_res.get("环境类型", ["未明确体现"]))
            env_effect = " / ".join(match_res.get("环境作用", ["未明确体现"]))

            # 自动补充高频环境作用
            if env_type != "未明确体现" and env_effect == "未明确体现":
                default_effects = ["渲染气氛", "烘托情感", "塑造意境"]
                env_effect = " / ".join(default_effects[:match_rule.get("max_match_num", 4)])

            detail_tpl = templates.get("detail", templates.get("base", "赏析模板缺失"))
            appreciation_result = detail_tpl.replace("【环境类型】", env_type) \
                .replace("【环境作用】", env_effect) \
                .replace("【原文依据】", original_basis)

            # 适配手机端展示
            appreciation_result = appreciation_result \
                .replace("<h2 style='color:#5C4033; margin:10px 0;'>", "") \
                .replace("<h3 style='color:#5C4033; margin:8px 0;'>", "") \
                .replace("<b>", "") \
                .replace("</b>", "") \
                .replace("</h2>", "") \
                .replace("</h3>", "") \
                .replace('<br>', '\n') \
                .replace("## ", "") \
                .replace("### ", "") \
                .replace("#", "")
            return appreciation_result
        except Exception as e:
            return f"⚠️ 环境描写赏析出错：{str(e)}"

    def appreciate_plot(self, text):
        """情节作用赏析"""
        try:
            appr_lib = self._load_appreciation_lib("plot")
            if not appr_lib:
                return "⚠️ 情节作用赏析词库未加载，请检查gaokao_appr_plot.json文件！"

            keyword_lib = appr_lib.get("keyword_lib", {})
            templates = appr_lib.get("appreciation_template", {})
            match_rule = appr_lib.get("match_rule", {})
            if not all([keyword_lib, templates]):
                return "⚠️ 情节作用赏析词库配置不完整！"

            match_res = self._match_keywords(text, keyword_lib, match_rule)
            original_basis = self._extract_original_basis(text, match_rule.get("extract_len", 30))
            plot_func = " / ".join(match_res.get("情节作用", ["未明确体现"]))
            plot_structure = " / ".join(match_res.get("结构特点", ["未明确体现"]))

            detail_tpl = templates.get("detail", templates.get("base", "赏析模板缺失"))
            appreciation_result = detail_tpl.replace("【情节作用】", plot_func) \
                .replace("【结构特点】", plot_structure) \
                .replace("【原文依据】", original_basis)

            # 适配手机端展示
            appreciation_result = appreciation_result \
                .replace("<h2 style='color:#5C4033; margin:10px 0;'>", "") \
                .replace("<h3 style='color:#5C4033; margin:8px 0;'>", "") \
                .replace("<b>", "") \
                .replace("</b>", "") \
                .replace("</h2>", "") \
                .replace("</h3>", "") \
                .replace('<br>', '\n') \
                .replace("## ", "") \
                .replace("### ", "") \
                .replace("#", "")
            return appreciation_result
        except Exception as e:
            return f"⚠️ 情节作用赏析出错：{str(e)}"

    def appreciate_rhetoric(self, text):
        """修辞手法赏析"""
        try:
            appr_lib = self._load_appreciation_lib("rhetoric")
            if not appr_lib:
                return "⚠️ 修辞手法赏析词库未加载，请检查gaokao_appr_rhetoric.json文件！"

            keyword_lib = appr_lib.get("keyword_lib", {})
            templates = appr_lib.get("appreciation_template", {})
            match_rule = appr_lib.get("match_rule", {})
            if not all([keyword_lib, templates]):
                return "⚠️ 修辞手法赏析词库配置不完整！"

            match_res = self._match_keywords(text, keyword_lib, match_rule)
            original_basis = self._extract_original_basis(text, match_rule.get("extract_len", 30))
            rhetoric_type = " / ".join(match_res.get("修辞类型", ["未明确体现"]))
            rhetoric_effect = " / ".join(match_res.get("表达效果", ["未明确体现"]))

            detail_tpl = templates.get("detail", templates.get("base", "赏析模板缺失"))
            appreciation_result = detail_tpl.replace("【修辞类型】", rhetoric_type) \
                .replace("【表达效果】", rhetoric_effect) \
                .replace("【原文依据】", original_basis)

            # 适配手机端展示
            appreciation_result = appreciation_result \
                .replace("<h2 style='color:#5C4033; margin:10px 0;'>", "") \
                .replace("<h3 style='color:#5C4033; margin:8px 0;'>", "") \
                .replace("<b>", "") \
                .replace("</b>", "") \
                .replace("</h2>", "") \
                .replace("</h3>", "") \
                .replace('<br>', '\n') \
                .replace("## ", "") \
                .replace("### ", "") \
                .replace("#", "")
            return appreciation_result
        except Exception as e:
            return f"⚠️ 修辞手法赏析出错：{str(e)}"

    def appreciate_theme(self, text):
        """情感主旨赏析"""
        try:
            appr_lib = self._load_appreciation_lib("theme")
            if not appr_lib:
                return "⚠️ 情感主旨赏析词库未加载，请检查gaokao_appr_theme.json文件！"

            keyword_lib = appr_lib.get("keyword_lib", {})
            templates = appr_lib.get("appreciation_template", {})
            match_rule = appr_lib.get("match_rule", {})
            if not all([keyword_lib, templates]):
                return "⚠️ 情感主旨赏析词库配置不完整！"

            match_res = self._match_keywords(text, keyword_lib, match_rule)
            original_basis = self._extract_original_basis(text, match_rule.get("extract_len", 30))
            emotion_type = " / ".join(match_res.get("情感类型", ["未明确体现"]))

            detail_tpl = templates.get("detail", templates.get("base", "赏析模板缺失"))
            appreciation_result = detail_tpl.replace("{{情感类型}}", emotion_type) \
                .replace("{{原文依据}}", original_basis) \
                .replace("【情感类型】", emotion_type) \
                .replace("【原文依据】", original_basis)

            # 适配手机端展示
            appreciation_result = appreciation_result \
                .replace("<h2 style='color:#5C4033; margin:10px 0;'>", "") \
                .replace("<h3 style='color:#5C4033; margin:8px 0;'>", "") \
                .replace("<b>", "") \
                .replace("</b>", "") \
                .replace("</h2>", "") \
                .replace("</h3>", "") \
                .replace('<br>', '\n') \
                .replace("## ", "") \
                .replace("### ", "") \
                .replace("#", "")
            return appreciation_result
        except Exception as e:
            return f"⚠️ 情感主旨赏析出错：{str(e)}"

    def appreciate_language(self, text):
        """语言风格赏析"""
        try:
            appr_lib = self._load_appreciation_lib("language")
            if not appr_lib:
                return "⚠️ 语言风格赏析词库未加载，请检查gaokao_appr_language.json文件！"

            keyword_lib = appr_lib.get("keyword_lib", {})
            templates = appr_lib.get("appreciation_template", {})
            match_rule = appr_lib.get("match_rule", {})
            if not all([keyword_lib, templates]):
                return "⚠️ 语言风格赏析词库配置不完整！"

            match_res = self._match_keywords(text, keyword_lib, match_rule)
            original_basis = self._extract_original_basis(text, match_rule.get("extract_len", 30))
            lang_style = " / ".join(match_res.get("风格类型", ["未明确体现"]))
            lang_feat = " / ".join(match_res.get("表达效果", ["未明确体现"]))

            # 动态填充风格描述
            style_desc_map = {
                "婉约细腻": "多用叠词、轻柔动词，细腻刻画情感与景物",
                "豪放雄健": "用词宏阔，句式奔放，营造开阔意境",
                "质朴平实": "用词朴素，句式简短，贴近生活细节",
                "典雅庄重": "用词考究，多用整句、对仗句，富有文化底蕴"
            }
            emotion_desc_map = {
                "婉约细腻": "凄苦的离愁别绪",
                "豪放雄健": "激昂的壮志豪情",
                "质朴平实": "真挚的生活情感",
                "典雅庄重": "深沉的思想内涵"
            }
            content_desc = style_desc_map.get(lang_style.split(" / ")[0], "通过词汇、句式的巧妙运用")
            emotion_desc = emotion_desc_map.get(lang_style.split(" / ")[0], "核心情感")

            detail_tpl = templates.get("detail", templates.get("base", "赏析模板缺失"))
            appreciation_result = detail_tpl.replace('【风格类型】', lang_style) \
                .replace('【表达效果】', lang_feat) \
                .replace('【原文依据】', original_basis) \
                .replace('{词汇特点/句式特征/修辞运用}', content_desc) \
                .replace('{核心情感/观点}', emotion_desc)

            # 适配手机端展示
            appreciation_result = appreciation_result \
                .replace("<h2 style='color:#5C4033; margin:10px 0;'>", "") \
                .replace("<h3 style='color:#5C4033; margin:8px 0;'>", "") \
                .replace("<b>", "") \
                .replace("</b>", "") \
                .replace("</h2>", "") \
                .replace("</h3>", "") \
                .replace('<br>', '\n') \
                .replace("## ", "") \
                .replace("### ", "") \
                .replace("#", "")
            return appreciation_result
        except Exception as e:
            return f"⚠️ 语言风格赏析出错：{str(e)}"

    def appreciate_writing(self, text):
        """写作手法赏析"""
        try:
            appr_lib = self._load_appreciation_lib("writing")
            if not appr_lib:
                return "⚠️ 写作手法赏析词库未加载，请检查gaokao_appr_writing.json文件！"

            keyword_lib = appr_lib.get("keyword_lib", {})
            templates = appr_lib.get("appreciation_template", {})
            match_rule = appr_lib.get("match_rule", {})
            if not all([keyword_lib, templates]):
                return "⚠️ 写作手法赏析词库配置不完整！"

            match_res = self._match_keywords(text, keyword_lib, match_rule)
            original_basis = self._extract_original_basis(text, match_rule.get("extract_len", 30))
            write_skill = " / ".join(match_res.get("手法类型", ["未明确体现"]))
            write_effect = " / ".join(match_res.get("表达效果", ["未明确体现"]))

            detail_tpl = templates.get("detail", templates.get("base", "赏析模板缺失"))
            appreciation_result = detail_tpl.replace("【手法类型】", write_skill) \
                .replace("【表达效果】", write_effect) \
                .replace("【原文依据】", original_basis)

            # 适配手机端展示
            appreciation_result = appreciation_result \
                .replace("<h2 style='color:#5C4033; margin:10px 0;'>", "") \
                .replace("<h3 style='color:#5C4033; margin:8px 0;'>", "") \
                .replace("<b>", "") \
                .replace("</b>", "") \
                .replace("</h2>", "") \
                .replace("</h3>", "") \
                .replace('<br>', '\n') \
                .replace("## ", "") \
                .replace("### ", "") \
                .replace("#", "")
            return appreciation_result
        except Exception as e:
            return f"⚠️ 写作手法赏析出错：{str(e)}"

    def appreciate_skill(self, text):
        """表达技巧赏析"""
        try:
            appr_lib = self._load_appreciation_lib("skill")
            if not appr_lib:
                return "⚠️ 表达技巧赏析词库未加载，请检查gaokao_appr_skill.json文件！"

            keyword_lib = appr_lib.get("keyword_lib", {})
            templates = appr_lib.get("appreciation_template", {})
            match_rule = appr_lib.get("match_rule", {})
            if not all([keyword_lib, templates]):
                return "⚠️ 表达技巧赏析词库配置不完整！"

            match_res = self._match_keywords(text, keyword_lib, match_rule)
            original_basis = self._extract_original_basis(text, match_rule.get("extract_len", 40))
            skill_type = " / ".join(match_res.get("技巧类型", ["未明确体现"]))
            skill_effect = " / ".join(match_res.get("综合效果", ["未明确体现"]))

            detail_tpl = templates.get("detail", templates.get("base", "赏析模板缺失"))
            appreciation_result = detail_tpl.replace("【技巧类型】", skill_type) \
                .replace("【综合效果】", skill_effect) \
                .replace("【原文依据】", original_basis)

            # 适配手机端展示
            appreciation_result = appreciation_result \
                .replace("<h2 style='color:#5C4033; margin:10px 0;'>", "") \
                .replace("<h3 style='color:#5C4033; margin:8px 0;'>", "") \
                .replace("<b>", "") \
                .replace("</b>", "") \
                .replace("</h2>", "") \
                .replace("</h3>", "") \
                .replace('<br>', '\n') \
                .replace("## ", "") \
                .replace("### ", "") \
                .replace("#", "")
            return appreciation_result
        except Exception as e:
            return f"⚠️ 表达技巧赏析出错：{str(e)}"

    def appreciate_text(self, text, appr_type="character"):
        """赏析统一入口（支持8大维度）"""
        if appr_type == "character":
            return self.appreciate_character(text)
        elif appr_type == "environment":
            return self.appreciate_environment(text)
        elif appr_type == "plot":
            return self.appreciate_plot(text)
        elif appr_type == "rhetoric":
            return self.appreciate_rhetoric(text)
        elif appr_type == "theme":
            return self.appreciate_theme(text)
        elif appr_type == "language":
            return self.appreciate_language(text)
        elif appr_type == "writing":
            return self.appreciate_writing(text)
        elif appr_type == "skill":
            return self.appreciate_skill(text)
        else:
            return f"⚠️ 暂未支持{appr_type}赏析，当前已支持高考8大核心维度：人物形象/环境描写/情节作用/修辞手法/情感主旨/语言风格/写作手法/表达技巧～"

    # ==================== 原有功能保留 ====================
    def get_daily_encouragement(self):
        """每日励志语"""
        return random.choice(ENCOURAGEMENT_WORDS) if ENCOURAGEMENT_WORDS else "每一次努力，都是向成功靠近的一步🚀"

    def save_create_record(self, create_info):
        """保存创作记录"""
        all_records = self._load_json(self.create_records_path, {})
        username = create_info.get("username")
        if username not in all_records:
            all_records[username] = []
        all_records[username].append(create_info)
        self._save_json(self.create_records_path, all_records)

    def get_create_records(self, username):
        """获取用户创作记录"""
        all_records = self._load_json(self.create_records_path, {})
        user_records = all_records.get(username, [])
        user_records.sort(key=lambda x: x.get("create_time", ""), reverse=True)
        return len(user_records), user_records

    def get_create_record_by_time(self, username, create_time):
        """按时间查询创作记录"""
        all_records = self._load_json(self.create_records_path, {})
        user_records = all_records.get(username, [])
        for record in user_records:
            if record.get("create_time") == create_time:
                return record
        return None

    def check_today_checkin(self, username):
        """校验今日打卡状态"""
        records = self._load_json(self.checkin_records_path, {})
        user_records = records.get(username, [])
        today_date = datetime.now().strftime("%Y-%m-%d")
        today_record = None
        for record in user_records:
            record_time = record.get("checkin_time", record.get("date", ""))
            if record_time.startswith(today_date):
                today_record = record
                break

        # 今日学习推荐
        def _get_daily_recommend():
            try:
                choose_type = random.choice(["poem", "prose"])
                if choose_type == "poem":
                    poems = self._load_json(self.gaokao_poems_path, [])
                    if not poems:
                        return ("诗词赏析专区", "《登高》（杜甫）")
                    poem = random.choice(poems)
                    title = poem.get("title", "未知诗词")
                    author = poem.get("author", "未知作者")
                    return ("诗词赏析专区", f"《{title}》（{author}）")
                else:
                    proses = self._load_json(self.gaokao_proses_path, [])
                    if not proses:
                        return ("古文赏析专区", "《赤壁赋》（苏轼）")
                    prose = random.choice(proses)
                    title = prose.get("title", "未知古文")
                    author = prose.get("author", "未知作者")
                    return ("古文赏析专区", f"《{title}》（{author}）")
            except Exception:
                return ("诗词赏析专区", "《念奴娇·赤壁怀古》（苏轼）")

        recommend_info = _get_daily_recommend()
        if today_record:
            today_word = today_record.get("encouragement_word", today_record.get("word", ""))
            return True, today_word, recommend_info
        return False, "", recommend_info

    def checkin(self, username, nickname=""):
        """用户打卡"""
        is_checked, _, recommend_info = self.check_today_checkin(username)
        if is_checked:
            call = nickname if nickname else f"{username}阁下"
            return f"{call}，今日已打卡啦～无需重复打卡！", 0, recommend_info

        records = self._load_json(self.checkin_records_path, {})
        if username not in records:
            records[username] = []
        today = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        word = self.get_daily_encouragement()
        records[username].append({"checkin_time": today, "encouragement_word": word})
        self._save_json(self.checkin_records_path, records)

        # 统计连续打卡天数
        continue_days = 1
        user_records = sorted(records[username], key=lambda x: x.get("checkin_time", x.get("date", "")))
        for i in range(len(user_records) - 2, -1, -1):
            prev_time = user_records[i].get("checkin_time", user_records[i].get("date", ""))
            curr_time = user_records[i + 1].get("checkin_time", user_records[i + 1].get("date", ""))
            try:
                prev_date = datetime.strptime(prev_time[:10], "%Y-%m-%d")
                curr_date = datetime.strptime(curr_time[:10], "%Y-%m-%d")
                if (curr_date - prev_date).days == 1:
                    continue_days += 1
                else:
                    break
            except Exception:
                break

        call = nickname if nickname else f"{username}阁下"
        result_text = f"{call}，今日打卡成功！✨\n{word}"
        return result_text, continue_days, recommend_info

    def get_checkin_records(self, username):
        """获取打卡记录"""
        records = self._load_json(self.checkin_records_path, {})
        user_records = records.get(username, [])
        total_count = len(user_records)
        continue_days = 1

        if total_count > 1:
            sorted_records = sorted(user_records, key=lambda x: x.get("checkin_time", x.get("date", "")))
            for i in range(len(sorted_records) - 2, -1, -1):
                prev_time = sorted_records[i].get("checkin_time", sorted_records[i].get("date", ""))
                curr_time = sorted_records[i + 1].get("checkin_time", sorted_records[i + 1].get("date", ""))
                try:
                    prev_date = datetime.strptime(prev_time[:10], "%Y-%m-%d")
                    curr_date = datetime.strptime(curr_time[:10], "%Y-%m-%d")
                    if (curr_date - prev_date).days == 1:
                        continue_days += 1
                    else:
                        break
                except Exception:
                    break

        format_records = []
        for record in user_records:
            format_records.append({
                "checkin_time": record.get("checkin_time", record.get("date", "未知时间")),
                "encouragement_word": record.get("encouragement_word", record.get("word", "——"))
            })
        return total_count, continue_days, format_records[::-1]

    def set_user_goal(self, username, goal, is_finish=False, nickname=""):
        """设置用户目标"""
        goals = self._load_json(self.user_goals_path, {})
        if username not in goals or isinstance(goals[username], str):
            goals[username] = []
        goals[username].append((goal, is_finish))
        self._save_json(self.user_goals_path, goals)
        call = nickname if nickname else f"{username}阁下"
        return f"已为{call}设置目标：{goal}"

    def get_all_user_goals(self, username):
        """获取用户所有目标"""
        goals = self._load_json(self.user_goals_path, {})
        user_goal = goals.get(username)
        if not user_goal:
            return []
        return [(user_goal, False)] if isinstance(user_goal, str) else user_goal

    def update_user_goals(self, username, goals_list):
        """更新用户目标"""
        goals = self._load_json(self.user_goals_path, {})
        goals[username] = goals_list
        self._save_json(self.user_goals_path, goals)

    def verify_user_pwd(self, username, password):
        """验证用户密码"""
        user_data = self._load_json(self.user_data_path, {})
        if username not in user_data:
            return False
        return user_data[username]["password"] == password

    def update_user_info(self, old_username, new_user_info):
        """更新用户信息"""
        user_data = self._load_json(self.user_data_path, {})
        if old_username in user_data:
            del user_data[old_username]
        new_username = new_user_info.get("username")
        if new_username:
            user_data[new_username] = new_user_info
        self._save_json(self.user_data_path, user_data)
        return True


# 实例化供外部调用
kivy_text_processor = KivyTextProcessor()